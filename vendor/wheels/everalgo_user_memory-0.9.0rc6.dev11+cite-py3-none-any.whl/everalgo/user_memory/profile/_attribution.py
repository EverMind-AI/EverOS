"""A multi-person update's attribution checks: does an operation rest on its own person?

One update call for several people of one conversation can put a fact on the wrong person. Before a person's
operations apply, each one is checked against what it rests on, in this order, and left out at the first check it
fails:

- ``other_ref``: its ref names an item of another person's profile (refs carry the person's label: ``p2.e3``);
- ``other_segment``: it names segments of the call, and none of them is one the person is updated from;
- ``other_picture``: it names pictures, and every one of them was posted by someone else;
- ``other_speaker``: its evidence or basis quotes lines, every one of them written by another speaker.

A quote found in no line of the conversation keeps its operation, as does an operation that quotes nothing: a quote
may be lightly paraphrased, or come from a conversation an earlier update read. Both are counted
(:class:`~._result.AttributionCounts`), so a host sees how often a check could not decide.

A quote is a passage of the evidence or basis between single, double, curly or corner quotes; an ellipsis splits it
into parts, each matched on its own. Matching sets case, spacing and punctuation aside and needs a part as long as a
few words (:data:`_MIN_QUOTE_WIDTH`), so "yes" or "ok" decides nothing.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from everalgo.user_memory._render import chat_messages
from everalgo.user_memory.profile._replies import (
    _AddItemOp,
    _DeprecateItemOp,
    _ExplicitItem,
    _ImplicitTrait,
    _ModifyItemOp,
)
from everalgo.user_memory.profile._result import AttributionCounts
from everalgo.utils import ascii_width

if TYPE_CHECKING:
    from collections.abc import Collection, Sequence

    from everalgo.types import MemCell
    from everalgo.user_memory.profile._replies import _ItemOperation

_MIN_QUOTE_WIDTH = 10
"""The shortest quote part matched, in ascii_width units (an East Asian wide character counts 2): two short English
words, or five Chinese characters."""

# A single or curly-single quote opens after a non-word character and closes before one; between them an apostrophe
# inside a word ("I'm") does not close it.
_QUOTED = (
    re.compile(r"(?<!\w)'((?:[^']|(?<=\w)'(?=\w))+)'(?!\w)"),
    re.compile("(?<!\\w)\u2018((?:[^\u2019]|(?<=\\w)\u2019(?=\\w))+)\u2019(?!\\w)"),
    re.compile(r'"([^"]+)"'),
    re.compile("\u201c([^\u201d]+)\u201d"),
    re.compile("\u300c([^\u300d]+)\u300d"),
    re.compile("\u300e([^\u300f]+)\u300f"),
)
_ELLIPSIS = re.compile(r"\.{3,}|\u2026+")
_NOT_WORD = re.compile(r"[\W_]+")
_LABELLED_REF = re.compile(r"^\s*\[?\s*(p\d+)\s*[.:/]\s*([et]\d+)\s*\]?\s*$", re.IGNORECASE)


def normal(text: str) -> str:
    """``text`` as quotes and lines are compared: case folded, every run of punctuation or space one space."""
    return " ".join(_NOT_WORD.sub(" ", text.casefold()).split())


def quote_parts(text: str) -> list[str]:
    """The quoted passages of ``text``, split at ellipses, normalised, each long enough to match."""
    parts: list[str] = []
    for pattern in _QUOTED:
        for match in pattern.finditer(text):
            for part in _ELLIPSIS.split(match.group(1)):
                normalised = normal(part)
                if ascii_width(normalised) >= _MIN_QUOTE_WIDTH and normalised not in parts:
                    parts.append(normalised)
    return parts


@dataclass(frozen=True)
class Lines:
    """Every message of the conversation with text, normalised, by sender: whose line it is."""

    by_sender: dict[str, list[str]] = field(default_factory=dict)

    @classmethod
    def of(cls, memcells: Sequence[MemCell]) -> Lines:
        """The lines of ``memcells``, by whose they are.

        A person's own are their ``role == "user"`` messages; every other message, an assistant's included, is
        someone else's.
        """
        by_sender: dict[str, list[str]] = {}
        for cell in memcells:
            for message in chat_messages(cell):
                if not message.content:
                    continue
                who = message.sender_id if message.role == "user" else f"\x00{message.role}:{message.sender_id}"
                by_sender.setdefault(who, []).append(normal(message.content))
        return cls(by_sender)

    def found(self, parts: Sequence[str], *, own: str) -> tuple[bool, bool]:
        """Whether a part is in one of ``own``'s lines, and whether one is in another speaker's."""
        mine = any(part in line for part in parts for line in self.by_sender.get(own, ()))
        if mine:
            return True, False
        others = any(
            part in line for who, lines in self.by_sender.items() if who != own for line in lines for part in parts
        )
        return False, others


_DROPPED = frozenset({"other_ref", "other_segment", "other_picture", "other_speaker"})


def screen(
    operations: Sequence[_ItemOperation],
    *,
    person: str,
    label: str,
    shown_segments: Collection[str],
    own_segments: Collection[str],
    own_pictures: Collection[str],
    other_pictures: Collection[str],
    lines: Lines,
) -> tuple[list[_ItemOperation], AttributionCounts]:
    """The operations of ``person`` that rest on them, each ref as their own profile shows it, and the counts.

    Args:
        operations: The reply's operations for the person, as read.
        person: Their sender id.
        label: The label their refs carry (``p1``); a ref carrying it is read without it (``e3``), a ref carrying
            another label is another person's, a ref carrying none is read as theirs.
        shown_segments: The labels of every segment the call showed (``s1``...).
        own_segments: Of those, the ones the person is updated from.
        own_pictures: The labels of the pictures the person posted.
        other_pictures: The labels of the pictures the other people of the call posted.
        lines: The conversation's lines.

    Returns:
        ``(operations, counts)``: the kept operations in reply order, and how every add, modify and deprecate fared.
    """
    check = _Check(
        person=person,
        label=label,
        shown_segments=shown_segments,
        own_segments=own_segments,
        own_pictures=own_pictures,
        other_pictures=other_pictures,
        lines=lines,
    )
    tally: Counter[str] = Counter()
    kept: list[_ItemOperation] = []
    for op in operations:
        if not isinstance(op, _AddItemOp | _ModifyItemOp | _DeprecateItemOp):
            kept.append(op)
            continue
        outcome, checked = check.outcome(op)
        tally[outcome] += 1
        if outcome not in _DROPPED:
            kept.append(checked)
    return kept, AttributionCounts(**tally)


@dataclass(frozen=True, kw_only=True)
class _Check:
    """What one person's operations are checked against (see :func:`screen`)."""

    person: str
    label: str
    shown_segments: Collection[str]
    own_segments: Collection[str]
    own_pictures: Collection[str]
    other_pictures: Collection[str]
    lines: Lines

    def outcome(
        self, op: _AddItemOp | _ModifyItemOp | _DeprecateItemOp
    ) -> tuple[str, _AddItemOp | _ModifyItemOp | _DeprecateItemOp]:
        """The first check ``op`` fails, or how it was kept; and ``op`` with its ref as the person's profile shows it."""
        if isinstance(op, _ModifyItemOp | _DeprecateItemOp):
            ref = _own_ref(op.ref, self.label)
            if ref is None:
                return "other_ref", op
            op = op.model_copy(update={"ref": ref})
        named = [source.strip() for source in op.sources if source.strip() in self.shown_segments]
        if named and not any(source in self.own_segments for source in named):
            return "other_segment", op
        if isinstance(op, _DeprecateItemOp):
            return "unquoted", op
        known = [p.strip() for p in op.pictures if p.strip() in self.own_pictures or p.strip() in self.other_pictures]
        if known and not any(p in self.own_pictures for p in known):
            return "other_picture", op
        parts = quote_parts(_grounding(op.data))
        if not parts:
            return "unquoted", op
        mine, others = self.lines.found(parts, own=self.person)
        if mine:
            return "own", op
        return ("other_speaker" if others else "unmatched"), op


def _own_ref(ref: str, label: str) -> str | None:
    """``ref`` without the person's label; None when it carries another person's label."""
    match = _LABELLED_REF.match(ref)
    if match is None:
        return ref
    if match.group(1).lower() != label.lower():
        return None
    return match.group(2)


def _grounding(data: _ExplicitItem | _ImplicitTrait) -> str:
    """What an item rests on: an explicit_info item's evidence, a trait's basis."""
    return data.evidence if isinstance(data, _ExplicitItem) else data.basis
