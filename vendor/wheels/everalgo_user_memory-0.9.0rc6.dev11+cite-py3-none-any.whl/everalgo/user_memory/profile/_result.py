"""What a MemCell-path update takes besides the conversation, and what it returns besides the profile.

:class:`ProfilePicture` is a picture the target user posted, handed to the update with the host's own id for it.
:class:`ProfileUpdate` is the updated profile plus its lineage: how every item came to be (:class:`ItemOrigin`) and
which stored items the call took out and why (:class:`RetiredItem`). The lineage is what lets a host keep per-item
provenance — the segments and pictures an item rests on, merged when a consolidation merges items — and a history of
replaced values, without comparing texts; everalgo itself stores none of it.
"""

from __future__ import annotations

__all__ = [
    "AttributionCounts",
    "ItemOrigin",
    "ItemRef",
    "ProfilePicture",
    "ProfileTarget",
    "ProfileUpdate",
    "ProfileUpdates",
    "RetiredItem",
]

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from everalgo.llm import ImageUrlPart
    from everalgo.types import ExplicitInfoItem, ImplicitTraitItem, Profile

type Bucket = Literal["explicit_info", "implicit_traits"]

type ItemRef = tuple[Bucket, int]
"""An item's place in a profile: its bucket and its position in that bucket's list."""

type Change = Literal["kept", "added", "modified", "consolidated"]
type Retirement = Literal["modified", "deprecated", "consolidated"]


@dataclass(frozen=True, kw_only=True)
class ProfilePicture:
    """A picture the target user posted in one of the segments an update reads.

    Attributes:
        label: The name the conversation text gives it, as ``[IMAGE: <label>]`` where it was sent (``img-1``); the
            prompt shows the picture after a ``<picture>`` element carrying this label, and a reply names it so.
        id: The host's durable id for the picture (a content hash, say); the lineage reports this, never the label.
        part: The picture as the model receives it.
    """

    label: str
    id: str
    part: ImageUrlPart


@dataclass(frozen=True, kw_only=True)
class ItemOrigin:
    """How one item of an updated profile came to be.

    Attributes:
        change: ``kept`` — the stored item, untouched; ``added`` — new in this call; ``modified`` — a stored item an
            update op rewrote or gave fresh evidence, patched in place, so every key a host attached is still on it;
            ``consolidated`` — written by a consolidation from the items in ``from_items``.
        from_items: Where in the profile the call was given the item comes from: its own place for ``kept`` and
            ``modified``, every merged or split item's place for ``consolidated``, none for ``added`` (or for a
            consolidated item made only of items this call added).
        sources: The host's ids of the segments this call read the item from — for ``added`` and ``modified``, and
            for a ``consolidated`` item, those of the items this call added or modified that went into it.
        pictures: The host's ids of the pictures this call read the item off, on the same terms as ``sources``.
    """

    change: Change
    from_items: tuple[ItemRef, ...] = ()
    sources: tuple[str, ...] = ()
    pictures: tuple[str, ...] = ()


@dataclass(frozen=True, kw_only=True)
class RetiredItem:
    """A stored item an update took out of the profile, and why.

    Attributes:
        ref: Its place in the profile the call was given.
        item: The item as it was given, every key a host attached included.
        change: ``modified`` — an update op gave it a new value (``replaced_by`` names the item holding it);
            ``deprecated`` — an update op found it no longer true; ``consolidated`` — a consolidation merged it into
            the items in ``replaced_by``, or dropped it (``replaced_by`` empty, ``reason`` given).
        reason: The model's reason for a deprecation or a consolidation drop; empty otherwise.
        sources: The host's ids of the segments a deprecation rests on; empty otherwise.
        replaced_by: Where in the updated profile its successors are.
    """

    ref: ItemRef
    item: ExplicitInfoItem | ImplicitTraitItem
    change: Retirement
    reason: str = ""
    sources: tuple[str, ...] = ()
    replaced_by: tuple[ItemRef, ...] = ()


@dataclass(frozen=True, kw_only=True)
class ProfileUpdate:
    """An updated profile and its lineage.

    Attributes:
        profile: The profile after the update and any consolidation it triggered.
        explicit_info: One origin per item of ``profile.explicit_info``, in the same order.
        implicit_traits: One origin per item of ``profile.implicit_traits``, in the same order.
        retired: The stored items the call took out, in the order it took them.
        consolidated: The parts the call consolidated: ``"profile"`` for the whole profile, ``"<bucket>:<name>"`` for
            the items filed under one category or trait name.
    """

    profile: Profile
    explicit_info: tuple[ItemOrigin, ...]
    implicit_traits: tuple[ItemOrigin, ...]
    retired: tuple[RetiredItem, ...] = ()
    consolidated: tuple[str, ...] = field(default=())


@dataclass(frozen=True, kw_only=True)
class ProfileTarget:
    """One of the people a multi-person update writes the profile of.

    Attributes:
        sender_id: The person: a human (``role == "user"``) sender of the memcells.
        old_profile: Their stored profile, as the last update returned it; None for a person with none yet.
        segment_ids: The host ids of the segments their profile is updated from, each one holding a line of theirs;
            None for every segment that does. A segment they spoke in but leave out (one their profile has already
            read) is still shown, as part of the conversation, but nothing of theirs may rest on it alone.
        pictures: The labels of the call's pictures this person posted; a picture is evidence about its poster only.
    """

    sender_id: str
    old_profile: Profile | None = None
    segment_ids: Sequence[str] | None = None
    pictures: Sequence[str] = ()


@dataclass(frozen=True, kw_only=True)
class AttributionCounts:
    """How one person's operations in a multi-person reply fared against what they rest on.

    The quotes are the quoted passages of an add's or modify's evidence or basis (single, double, curly or corner
    quotes; an ellipsis splits one into parts), matched against every message of the conversation, case, spacing and
    punctuation set aside; a part shorter than a few words is not matched.

    Attributes:
        own: Kept: a quote is in one of the person's own lines.
        unmatched: Kept: its quotes are in no line of the conversation (paraphrased, or from a conversation an
            earlier update read).
        unquoted: Kept: it quotes nothing (a deprecation, a trait whose basis names its signals in other words).
        other_speaker: Left out: its quotes are in lines other speakers wrote, and none in the person's own.
        other_segment: Left out: it names only segments without a line of the person's (or only ones their
            ``ProfileTarget.segment_ids`` leave out).
        other_picture: Left out: it names only pictures someone else posted.
        other_ref: Left out: its ref names an item of another person's profile.
    """

    own: int = 0
    unmatched: int = 0
    unquoted: int = 0
    other_speaker: int = 0
    other_segment: int = 0
    other_picture: int = 0
    other_ref: int = 0

    @property
    def dropped(self) -> int:
        """The operations left out, whatever the reason."""
        return self.other_speaker + self.other_segment + self.other_picture + self.other_ref


@dataclass(frozen=True, kw_only=True)
class ProfileUpdates:
    """A multi-person update: each named person's updated profile and lineage, and every person's checks.

    Attributes:
        updates: By sender_id, a :class:`ProfileUpdate` for each target the reply named, in target order; a target
            the reply left out (nothing new for them) has none, and their stored profile stands as it is.
        attribution: By sender_id, every target's :class:`AttributionCounts` (all zero for one left out).
    """

    updates: Mapping[str, ProfileUpdate]
    attribution: Mapping[str, AttributionCounts]
