"""The reply model, the shape the original prompt's JSON skeleton shows, and the LLM callsite held to it.

``_EpisodeReply`` answers the original episode request. The callsite makes one call and validates the reply; there is no
retry here, the host decides (``docs/concepts/llm-contract.md`` §4, §5).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from pydantic import model_validator

from everalgo.llm import LLMMessage, LLMOutputError, StrictOutputModel, parse_reply

if TYPE_CHECKING:
    from everalgo.llm.protocols import LLMClient


class _EpisodeReply(StrictOutputModel):
    """Episode reply: the ``{"title", "content"}`` skeleton of the original prompt, in order.

    Only these two fields are read, as everalgo-user-memory 0.3.1 read the reply: it required them and ignored the rest.
    The original prompt does not forbid other keys and models add some (a ``summary``, keys of their own), so under JSON
    mode or a prompt-only call any other top-level key is dropped before validation, never failed; a schema-constrained
    call cannot write one (the strict schema still forbids them). The summary is cut from the content in code
    (``_summary._original_summary``).
    """

    title: str
    content: str

    @model_validator(mode="before")
    @classmethod
    def _read_only_the_fields(cls, value: object) -> object:
        if not isinstance(value, dict):
            return value
        reply = cast("dict[str, object]", value)
        return {key: item for key, item in reply.items() if key in cls.model_fields}


# The fields stored as text, which a blank value leaves without an honest stand-in.
_STORED_TEXT_FIELDS = ("content", "title")


async def _call_llm_for_episode(llm: LLMClient, messages: list[LLMMessage]) -> _EpisodeReply:
    """Request an episode reply and return it validated.

    Raises:
        LLMOutputError: If the reply is not a valid episode output, or leaves ``content`` or ``title`` blank.
    """
    text = await llm.achat(messages=messages, response_format=_EpisodeReply)
    reply = parse_reply(_EpisodeReply, text, operator="episode")
    _check_fields_written(reply, _STORED_TEXT_FIELDS, operator="episode")
    return reply


def _check_fields_written(reply: StrictOutputModel, fields: tuple[str, ...], *, operator: str) -> None:
    """Reject a reply that leaves one of ``fields``, each stored as text, blank (llm-contract §4.1).

    Raises:
        LLMOutputError: Naming ``operator`` and each blank field, never the reply's content.
    """
    blank = [name for name in fields if not getattr(reply, name).strip()]
    if blank:
        reasons = "; ".join(f"{name}: empty after stripping whitespace" for name in blank)
        raise LLMOutputError(f"{operator} reply leaves fields blank: {reasons}")
