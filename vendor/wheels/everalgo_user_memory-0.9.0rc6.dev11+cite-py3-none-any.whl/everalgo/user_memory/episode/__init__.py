"""Write one Episode — a titled third-person narrative — from a MemCell, with the original episode request.

The request is everalgo-user-memory 0.3.1's whole-memcell episode prompt (``prompts.en.episode_original``), filled as
0.3.1 filled it, then the ``<output_language>`` block, in one user message. The reply is ``title`` and ``content``; the
summary is the content's first 200 characters, cut in code.

Modules, each importing only those below it: ``_extractor`` (:class:`EpisodeExtractor`) wires ``_render`` (the request
the model is shown, also what a host renders when it sends the original request with blocks of its own), ``_replies``
(the reply model and the LLM callsite held to it) and ``_summary`` (the summary cut from the content).

Log lines, all on ``everalgo.user_memory.episode``; none carries a prompt or model text:

    ``extracting episode: <n> items, <n> rendered chars, output_language=<value>`` (INFO)
        Once per :class:`EpisodeExtractor` call, before the model is asked. ``rendered chars`` is the user message's
        length. ``output_language`` is the caller's argument as given.
    ``episode extracted: content <n> units, summary <n> units`` (INFO)
        Once per :class:`EpisodeExtractor` call that returns an Episode, widths in ASCII-equivalent units.
"""

from __future__ import annotations

__all__ = ["EpisodeExtractor"]

from everalgo.user_memory.episode._extractor import EpisodeExtractor
