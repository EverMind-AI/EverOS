"""The stored ``summary``: the content's first 200 characters, cut in code, as everalgo-user-memory 0.3.1 cut it.

The original prompt asks the model for no summary, so none is read from the reply: an episode's summary is always the
start of its own body, whichever model wrote it.
"""

from __future__ import annotations

# The original summary: the content cut at this many characters (everalgo-user-memory 0.3.1).
_ORIGINAL_SUMMARY_CHARS = 200


def _original_summary(content: str) -> str:
    """The summary an episode from the original request stores: the first 200 characters of ``content``.

    0.3.1 kept a non-blank ``summary`` a reply happened to carry, which its prompt never asks for; the summary is now
    always cut from the content.

    Args:
        content: The episode body.
    """
    return content[:_ORIGINAL_SUMMARY_CHARS]
