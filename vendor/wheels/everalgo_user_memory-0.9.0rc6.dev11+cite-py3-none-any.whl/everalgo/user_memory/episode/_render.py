"""What the model is shown: the original episode request, everalgo-user-memory 0.3.1's, in one user message.

:func:`_render_original_prompt` fills 0.3.1's whole-memcell ``EPISODE_GENERATION_PROMPT`` exactly as 0.3.1 filled it.
:func:`_render_messages` is the request :class:`~everalgo.user_memory.episode.EpisodeExtractor` sends: that text, then
one ``<output_language>`` block. A host that adds blocks of its own (pictures, a group roster) renders the original here
and appends them after it, so the text and its rendering stay everalgo's.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from everalgo.llm import LLMMessage
from everalgo.user_memory._language import PARTICIPANT_LANGUAGE_RULE, OutputLanguage, build_language_rule
from everalgo.user_memory._render import chat_messages
from everalgo.user_memory.prompts.en.episode_original import DEFAULT_CUSTOM_INSTRUCTIONS, EPISODE_GENERATION_PROMPT
from everalgo.utils import format_utc_time, render_prompt, tagged

if TYPE_CHECKING:
    from everalgo.types import MemCell


def _render_messages(
    memcell: MemCell,
    *,
    custom_instructions: str | None,
    output_language: OutputLanguage | None,
) -> list[LLMMessage]:
    """The one user message that asks for the episode: the original request, then the ``<output_language>`` block.

    The block follows the original's last line after one newline and holds the language the caller named, or the
    participant rule when none is named.

    Args:
        memcell: The cell to render (:func:`_render_original_prompt`).
        custom_instructions: The caller's text for the original's custom-instructions slot.
        output_language: The language the caller named, or None to have the model follow the participants.
    """
    original = _render_original_prompt(memcell, custom_instructions=custom_instructions)
    language = tagged("output_language", build_language_rule(output_language, fallback=PARTICIPANT_LANGUAGE_RULE))
    return [LLMMessage(role="user", content=f"{original}\n{language}")]


_MONTHS = (
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
)


def _render_original_prompt(memcell: MemCell, *, custom_instructions: str | None) -> str:
    """The original request: 0.3.1's ``EPISODE_GENERATION_PROMPT``, filled as 0.3.1 filled it, one user message.

    The conversation start time is the first item's time, each message with text is a pseudo-JSON block
    (:func:`_original_conversation`), and ``custom_instructions`` fills its slot, or the five default principles when it
    is ``None`` or empty, as 0.3.1's ``custom_instructions or DEFAULT_CUSTOM_INSTRUCTIONS`` did. Values land verbatim:
    a placeholder spelled inside a message stays as written.

    Args:
        memcell: The cell to render. Its first item gives the conversation start time.
        custom_instructions: The caller's text for the custom-instructions slot.

    Returns:
        The whole prompt, opening and ending with a newline as 0.3.1's did.
    """
    return render_prompt(
        EPISODE_GENERATION_PROMPT,
        None,
        conversation_start_time=_original_time(memcell.items[0].timestamp),
        conversation=_original_conversation(memcell),
        custom_instructions=custom_instructions or DEFAULT_CUSTOM_INSTRUCTIONS,
    )


def _original_time(timestamp_ms: int) -> str:
    """A time as the original prompt shows it, ``March 14, 2024 (Thursday) at 03:00 PM UTC``.

    everalgo-core 0.3.0's ``format_natural_language_time`` wording, reshaped from core's rendering of the instant,
    ``2024-03-14 15:00 UTC (Thursday)``: the month in words, the day zero-padded, the weekday, then a 12-hour clock
    with the hour zero-padded.
    """
    date, clock, _, weekday = format_utc_time(timestamp_ms, weekday=True).split(" ", 3)
    year, month, day = date.split("-")
    hour, minute = clock.split(":")
    half = "PM" if int(hour) >= 12 else "AM"
    return f"{_MONTHS[int(month) - 1]} {day}, {year} {weekday} at {int(hour) % 12 or 12:02d}:{minute} {half} UTC"


def _original_conversation(memcell: MemCell) -> str:
    """The ChatMessage items as 0.3.1 rendered them: one pseudo-JSON block per message with text, values unquoted.

    Each block opens with a newline and the blocks are joined by one, so a blank line separates two messages and the
    rendering opens with a newline. A message with no timestamp keeps its block without the ``timestamp`` line, as in
    0.3.1; one with no text is dropped.
    """
    blocks: list[str] = []
    for message in chat_messages(memcell):
        if not message.content:
            continue
        speaker = message.sender_name or message.sender_id
        if message.timestamp:
            blocks.append(
                f"""
                {{
                    "timestamp": {_original_time(message.timestamp)},
                    "speaker": {speaker},
                    "content": {message.content}
                }}"""
            )
        else:
            blocks.append(
                f"""
                {{
                    "speaker": {speaker},
                    "content": {message.content}
                }}"""
            )
    return "\n".join(blocks)
