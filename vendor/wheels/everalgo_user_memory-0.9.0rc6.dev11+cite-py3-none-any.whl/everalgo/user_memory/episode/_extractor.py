"""``EpisodeExtractor``: render the original request, make the one call, cut the summary, assemble the Episode."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from asgiref.sync import async_to_sync

from everalgo.types import Episode
from everalgo.user_memory._language import OutputLanguage, resolve_output_language
from everalgo.user_memory.episode._render import _render_messages
from everalgo.user_memory.episode._replies import _call_llm_for_episode, _EpisodeReply
from everalgo.user_memory.episode._summary import _original_summary
from everalgo.utils import ascii_width

if TYPE_CHECKING:
    from everalgo.llm.protocols import LLMClient
    from everalgo.types import MemCell

# The package's name rather than this module's: hosts collect the log contract under it.
logger = logging.getLogger("everalgo.user_memory.episode")


class EpisodeExtractor:
    """Extract one Episode from a MemCell with the original episode request: one LLM call, no retry.

    The request is everalgo-user-memory 0.3.1's whole-memcell episode prompt, filled as 0.3.1 filled it, then the
    ``<output_language>`` block, all in one user message. Non-ChatMessage items in ``memcell.items`` are silently
    skipped (agent → user-memory contract).

    Args:
        llm: The client the call goes through.
    """

    def __init__(self, *, llm: LLMClient) -> None:
        self._llm = llm

    async def aextract(
        self,
        memcell: MemCell,
        *,
        sender_id: str | None,
        custom_instructions: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Episode:
        """Extract one Episode from ``memcell``.

        Exceptions raised by the LLM client propagate unchanged.

        Args:
            memcell: Source slice from boundary detection. Its first item's time is the conversation start time, and
                each message with text is shown as a pseudo-JSON block with its own time.
            sender_id: Stored as the Episode's ``owner_id``; ``None`` for an episode bound to no user. The request is
                the same either way — it narrates the whole memcell.
            custom_instructions: The host's text, placed verbatim in the original prompt's custom-instructions slot in
                place of its five default principles and never rendered as a template; it cannot change the output
                shape. None or an empty string sends the default principles.
            output_language: Language to write the episode in, as an :class:`OutputLanguage` member or equivalent
                string in any casing, named in the ``<output_language>`` block after the original's text. Naming one
                removes the decision from the model; leaving it ``None`` sends the participant rule instead.

        Returns:
            The Episode: ``subject`` from the reply's ``title``, ``episode`` from its ``content`` verbatim, ``summary``
            the content's first 200 characters, ``timestamp`` from ``memcell``. Any other key the reply carries is
            ignored. It reports no language, named or not: a host that needs the episode's language judges it from the
            text.

        Raises:
            InvalidInputError: If ``output_language`` names no supported language.
            LLMOutputError: If the reply is not a valid episode output, or leaves ``content`` or ``title`` blank.
        """
        named_language = resolve_output_language(output_language)
        messages = _render_messages(memcell, custom_instructions=custom_instructions, output_language=named_language)
        logger.info(
            "extracting episode: %d items, %d rendered chars, output_language=%s",
            len(memcell.items),
            len(str(messages[0].content)),
            output_language,
        )
        reply = await _call_llm_for_episode(self._llm, messages)
        episode = _build_episode(reply, sender_id=sender_id, memcell=memcell)
        logger.info(
            "episode extracted: content %d units, summary %d units",
            ascii_width(episode.episode),
            ascii_width(episode.summary),
        )
        return episode

    extract = async_to_sync(aextract)


def _build_episode(reply: _EpisodeReply, *, sender_id: str | None, memcell: MemCell) -> Episode:
    """Assemble the :class:`Episode` from the reply and memcell, as 0.3.1 mapped it.

    ``title`` becomes ``subject`` and ``content`` the body, verbatim: every time a reader sees is one the model wrote,
    which the original prompt has it resolve against each message's own time. The summary is the body's start.
    """
    return Episode(
        owner_id=sender_id,
        episode=reply.content,
        subject=reply.title,
        summary=_original_summary(reply.content),
        timestamp=memcell.timestamp,
    )
