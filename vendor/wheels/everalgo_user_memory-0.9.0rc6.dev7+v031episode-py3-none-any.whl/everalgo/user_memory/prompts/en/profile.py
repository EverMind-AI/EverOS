"""English prompts for ProfileExtractor's MemCell path — v3: two prompts, update and consolidation.

The MemCell path is what a host calls on every new conversation segment, so its two prompts are the profile's whole
model-facing surface:

* ``PROFILE_UPDATE_SYSTEM_PROMPT`` / ``PROFILE_UPDATE_USER_PROMPT`` read the stored profile (empty for a person seen
  for the first time, which is what INIT used to be) and only the conversation no earlier update has read, and reply
  with operations: ``add`` / ``modify`` / ``deprecate`` / ``none``, each naming the segments (and pictures) it rests
  on. A changed value is a ``modify`` of the item holding the old one, addressed by the ``ref`` the stored profile
  shows it under, so the host can link the new value to the old.
* ``PROFILE_CONSOLIDATE_SYSTEM_PROMPT`` / ``PROFILE_CONSOLIDATE_USER_PROMPT`` replace COMPACT and REGROUP. They run
  only when the profile, or one category or trait name of it, is over its cap, and see only that part: they drop
  what was never a portrait item, merge restatements, split compound items and re-file items by dimension. The reply
  lists only what changes — every written item names the items it came from (``from``), every dropped one is listed
  with a reason, and an item the reply does not mention stays as it is, so an omission can never lose a fact.

Layout. Each stage is a system message of rules and a user message of data. The system message opens and closes
with the output-language rule (head and tail, as the MemCell prompts were measured with), names the target user
inside its rules (the naming example has to name the actual subject: a fixed placeholder name regressed trait
extraction to about zero in v1) and holds nothing that changes between two calls for the same person, so a prompt
cache shares it whole; the host's additional requirements, when given, close it in the Episode path's
``<additional_requirements>`` block. The user message carries only the
data, as XML elements: ``<stored_profile>`` or ``<items>`` hold one ``<item ref="e3">{json}</item>`` per item, each
item's fields grounding first and nothing a host attached (ids, provenance, dates), and ``<new_conversation>``
holds one ``<segment id="s1">`` element of rendered chat lines per segment. Pictures, when the host attaches any,
follow the text as image parts, each after a ``<picture>`` element naming its label.

Inherited measured lessons from v2 (the four-prompt MemCell path) that still bind here:

* A rule repeated in two places may be load-bearing; do not remove a copy without measuring.
* An example beats the rule it contradicts; every example follows every rule.
* Do not hand the model a list of label names to choose from: bold literals got copied verbatim.

What v3 changes and why, measured on 2026-11-11 through EverOS 2.0 (DeepSeek V4.1 Flash, LoCoMo conversations 0-1):
v2's UPDATE was sent the stored profile plus every segment of every cluster newer than it — 67 conversation lines
for a 17-line segment, 50 of them already read by earlier updates — and re-reading old conversation re-added what
was on file (all three ops of that call were duplicates of stored items), which pushed categories past their cap and
sent 63 of 82 updates on to REGROUP. The profile was 85% of the text write cost. v3 reads each segment once, and a
consolidation fires again on the same part only once that part has grown (see ``_items``).
"""

from __future__ import annotations

from everalgo.utils import paragraphs, tagged

# --------------------------------------------------------------------------------------------------
# Shared blocks: what a profile is, how items are written, whose profile it is.
# --------------------------------------------------------------------------------------------------

_WHAT_A_PROFILE_IS = paragraphs(
    "A profile is a portrait of a person, not a log of what happened. Nothing enters it because it occurred — only "
    "because it is still true the next time you meet this person. A long, busy conversation can correctly yield "
    "nothing at all.",
    "explicit_info holds what this person stated about themselves: their role, the constraints they work under, "
    "their environment, the people and pets in their life, the preferences they voiced. One clear statement is "
    'enough. It must also still hold next time: "I\'m tired today", "I\'m in a hurry right now", "I\'m on leave next '
    'week" were genuinely said and do not belong in a portrait. Anything you would have to infer from what they '
    "did does not belong here at all: watching an action tells you the action happened, not that this person holds "
    "a standing property. A single operation is an event, not a portrait fact.",
    "implicit_traits holds latent traits of this person, inferred from the conversation: how they decide, what "
    "they insist on, what they avoid, how they treat the people they talk with. A trait is a grounded inference — you read a disposition out of signals and "
    "name those signals in its basis. A signal is something this person chose or asserted, not an operation they "
    "carried out (running a test is an action, not a signal); one clear signal is enough, and signals need not "
    "share a topic, but the same statement twice is one signal, not two.",
    "Two gates admit an item: it must be a fact about this person, and only then does the bucket question arise. A "
    "rule that would hold for whoever sat in their seat — a team process, how a system works — is nobody's portrait "
    "fact, however clearly this person stated it. For what passes that gate, the bucket is decided by whether this "
    "person said it: anything traceable to a sentence they uttered is explicit_info, however much it also reveals "
    "about them; implicit_traits holds only what they never stated. Rephrasing a statement as a disposition is not "
    "an inference, and it belongs in explicit_info once, not in both buckets.",
    "Never restate an action as a capability, duty, skill, familiarity, interest or attitude. Having run the tests "
    "once is not being responsible for testing, and asking what a skipped test was is a question, not an attitude "
    "towards testing. A question records nothing about its topic, and being told something is not knowing it: "
    "what the assistant or another participant explained never becomes this person's knowledge. How this person "
    "treats the people they talk with — drawing them out about their lives, cheering them on, standing by them — is "
    "conduct they chose: a signal of a trait, never of an interest in what was discussed.",
)

_HOW_ITEMS_ARE_WRITTEN = paragraphs(
    "One fact, one item. An item states a single atomic fact about this person, in one or two short sentences — "
    'plain, direct and easy to read. Never chain separate facts together with "also", "as well as" or a comma-list: '
    '"prefers small pull requests, insists on rebase-before-merge, and reviews in the morning" is three items, not '
    'one. A statement that forms one fact stays one item — "works mainly in Python with some Rust" is one fact about '
    "their language stack.",
    "A category groups items; it never merges them. A category or trait name names a durable dimension of the "
    "person — their role, their family, their daily habits — and several items sharing one name is the normal, "
    "expected shape. A name describes the dimension of the fact itself, never the topic of the conversation it "
    "surfaced in. When a fact belongs to a dimension already on file, reuse that exact name; names are coarse and "
    "few, the items under them atomic and many.",
    "Never name the subject. A profile is read as being about this one person, so state each item directly: "
    '"Works mainly in Python", never "{{target_user}} works mainly in Python" or "the user works mainly in Python". '
    "This holds in evidence too — give what was said and when, not who said it.",
    'An explicit_info item is {"evidence", "description", "category"}; an implicit_traits item is {"basis", '
    '"description", "trait"}. "evidence" and "basis" are JSON strings, never arrays. "evidence" gives when something '
    "was said and quotes it, naming no one — \"2024-10-03: '...'\" — and carries at most two dated quotes; when a "
    'third arrives, keep the two most recent. "basis" names the signals themselves, each one findable in the '
    'conversation; restating the requirement ("one clear signal", "repeated choices") is not a basis, and if you '
    "cannot name the signals, the trait does not belong in the profile.",
)

_TARGET_USER = (
    "The target user is {{target_user}}, the speaker whose lines are tagged user_id:{{target_user_id}}. The "
    "conversation may have several speakers; anything stated by or about another participant belongs to that "
    "participant, and an assistant's suggestions are not this person's traits. The name and id only locate their "
    "lines — neither appears in your output."
)

# --------------------------------------------------------------------------------------------------
# UPDATE — operations against the stored profile, from the new conversation only.
# --------------------------------------------------------------------------------------------------

_ROLE_UPDATE = (
    "You are a user-profile updater. The target user's stored profile is in <stored_profile>, empty when nothing is "
    "on file yet, and the new conversation, which no earlier update has read, is in <new_conversation>. Decide which "
    "operations bring the stored profile up to date with what the new conversation shows about the target user, "
    "following the rules below."
)

_OPERATIONS = """\
- add: a fact not on file. A new fact in a dimension already on file is still an add, filed under that category or trait name as a sibling item. A second copy of a fact already on file is never an add.
- modify: the new conversation changes, corrects or sharpens a fact on file, or gives fresh evidence for it. "ref" names that item exactly as <stored_profile> lists it, and "data" restates the whole item, its unchanged fields included, so a description always travels with its grounding. When a value this person stated changes — another city, job, partner, pet, a reversed preference — modify the item that holds the old value: never add a second item beside it, and never keep both values in one description. A modify stays on that item's own fact; it never widens the item to absorb a different one.
- deprecate: an item on file that the new conversation shows is no longer true and leaves no new value in its place (they gave up the hobby, the plan fell through, they retracted it), or that asserts a duty, capability, skill, familiarity, interest or attitude this person never claimed. "ref" names it and "reason" says what the conversation showed.
- none: nothing in the new conversation changes the profile. This is often the right answer: a conversation of tasks, small talk or another person's news says nothing about who this person is, however long it is."""

_SOURCES_AND_PICTURES = paragraphs(
    'Every add, modify and deprecate lists in "sources" the ids of the segments it rests on, as the <segment> '
    'elements of <new_conversation> name them ("s1"), and in "pictures" the labels of the pictures it was read off '
    '("img-1"); a fact the messages state lists no picture.',
    "Pictures, when any are attached after the conversation, are pictures the target user posted, each after a "
    "<picture> element naming its label; the conversation marks where each was sent as [IMAGE: img-1]. A picture "
    "is evidence about this person like a sentence they wrote: what it shows about their life — a pet and its name, "
    "a home, a hobby, a workplace, a possession — can enter the profile, and the moment it captures cannot. Record "
    "what the picture shows, never what it suggests about their character; the evidence of such a fact says what "
    "the picture shows and when it was sent.",
)

_UPDATE_RULES = """\
1. A ref names one item of <stored_profile>: an e-ref an explicit_info item, a t-ref an implicit_traits item. Refs resolve against the profile exactly as listed; the operations of one reply never shift each other's refs. An add takes no ref.
2. Before an add, look for the same fact on file under any wording: found means modify, or nothing when the conversation adds nothing to it.
3. A modify or deprecate changes only the item its ref names; it never merges two items.
4. Look for traits actively: a new conversation with any substance usually shows something of how this person decides, what they insist on, what they avoid or how they treat the people they talk with, and leaves the traits untouched only when it is purely operational. Several remarks showing one disposition make one trait with several signals, not one trait each. A trait it shows that is not on file under any wording is an add; a disposition on file that it shows again needs nothing unless the new signals change it, and never a second item beside it."""

_UPDATE_REPLY_FORMAT = paragraphs(
    "Reply with one JSON object, nothing else. Write each item's fields in the order shown, evidence or basis first.",
    '{"operations": ['
    '{"action": "add", "type": "explicit_info", "data": {"evidence": "...", "description": "...", "category": "..."}, '
    '"sources": ["s1"], "pictures": []}, '
    '{"action": "modify", "ref": "t2", "data": {"basis": "...", "description": "...", "trait": "..."}, '
    '"sources": ["s1"], "pictures": []}, '
    '{"action": "deprecate", "ref": "e4", "reason": "...", "sources": ["s1"]}'
    "]}",
    'With nothing to change: {"operations": [{"action": "none"}]}',
)

PROFILE_UPDATE_SYSTEM_PROMPT = "\n\n".join(
    (
        "{{language_rule}}",
        _ROLE_UPDATE,
        tagged("what_a_profile_is", _WHAT_A_PROFILE_IS),
        tagged("how_items_are_written", _HOW_ITEMS_ARE_WRITTEN),
        tagged("target_user", _TARGET_USER),
        tagged("operations", _OPERATIONS),
        tagged("sources_and_pictures", _SOURCES_AND_PICTURES),
        tagged("rules", _UPDATE_RULES),
        tagged("reply_format", _UPDATE_REPLY_FORMAT),
        tagged("output_language", "{{language_rule}}"),
    )
)

PROFILE_UPDATE_USER_PROMPT = "\n\n".join(
    (
        tagged("stored_profile", "{{stored_profile}}"),
        tagged("new_conversation", "{{segments}}"),
    )
)
"""The data of an update: ``{{segments}}`` holds one ``<segment id="sN">`` element per segment. When the host
attaches pictures, a ``<pictures>`` element naming their labels follows, and then the pictures themselves."""


# --------------------------------------------------------------------------------------------------
# CONSOLIDATE — rewrite the part of the profile that is over its cap, and only that part.
# --------------------------------------------------------------------------------------------------

_ROLE_CONSOLIDATE = (
    "You are a user-profile editor. Part of the target user's stored profile has outgrown its cap: <scope> says "
    "which part — the whole profile, or the items filed under one category or trait name — and <items> lists that "
    "part's items. Rewrite that part into a clean one, following the rules below. The rest of the profile is not "
    "shown and stays as it is; <other_names> lists the category and trait names it uses."
)

_HOW_TO_CONSOLIDATE = """\
Work in this order.
1. Drop every item that was never a portrait item: an action restated as a capability, duty, skill, familiarity, interest or attitude; a passing state; anything trivial or already expired; a fact about someone else; a trait that only restates something this person said. Drop it outright, do not merge it: folding twelve "responsible for testing" items into one still leaves a claim this person never made.
2. Merge items that say the same thing: they become one item, keeping the better wording and at most the two most recent dated quotes of their evidence. Distinct facts stay distinct items; never collapse a dimension's items into one summary item.
3. Split an item that chains several independent facts into one item per fact, each keeping the evidence of its own fact.
4. File every item under the name of its own dimension. Reuse a name from <items> or <other_names> when one fits, otherwise coin a coarse new one; near-synonymous names for one dimension take the name that covers most of its items. Re-filing renames; it never rewrites a description.
5. Never invent a fact, a quote or a basis, and never move an item between explicit_info and implicit_traits: every item you write rests on the items it came from, in their bucket.
6. The caps — {{max_per_category}} items under one name, {{max_traits}} traits, {{max_items}} in the whole profile — are ceilings, not targets. Meet them by dropping and merging, never by deleting a real fact; a part that cannot get under its cap stays over it."""

_CONSOLIDATE_REPLY_FORMAT = paragraphs(
    'Reply with your changes only. List in "changes" each item a change writes — the one item a merge makes, each '
    'item of a split, an item reworded or filed under another name — with "from" naming the refs of the items in '
    '<items> it came from, and list in "dropped" every item you drop, with the reason. An item you keep exactly as '
    "it is, the same description under the same name, is not a change: leave it out of the reply and it stays as "
    "it is. Most replies name only a few of the items. Reply with one JSON object, nothing else. Write each item's "
    "fields in the order shown, from first and then evidence or basis.",
    '{"changes": ['
    '{"from": ["e3", "e7"], "evidence": "...", "description": "...", "category": "..."}, '
    '{"from": ["t2"], "basis": "...", "description": "...", "trait": "..."}'
    '], "dropped": [{"ref": "e5", "reason": "..."}]}',
    'With nothing to change: {"changes": [], "dropped": []}',
)

PROFILE_CONSOLIDATE_SYSTEM_PROMPT = "\n\n".join(
    (
        "{{language_rule}}",
        _ROLE_CONSOLIDATE,
        tagged("what_a_profile_is", _WHAT_A_PROFILE_IS),
        tagged("how_items_are_written", _HOW_ITEMS_ARE_WRITTEN),
        tagged("target_user", _TARGET_USER),
        tagged("how_to_consolidate", _HOW_TO_CONSOLIDATE),
        tagged("reply_format", _CONSOLIDATE_REPLY_FORMAT),
        tagged("output_language", "{{language_rule}}"),
    )
)

PROFILE_CONSOLIDATE_USER_PROMPT = "\n\n".join(
    (
        tagged("scope", "{{scope}}"),
        tagged("other_names", "{{other_names}}"),
        tagged("items", "{{items}}"),
    )
)
