"""Reading a profile reply leniently in form, never in meaning.

A reply requested in JSON mode is JSON, but not always the JSON the reply model describes, and on the MemCell path
each such slip used to fail the whole reply: the host called again with the whole prompt, or lost the update. What
this module accepts, and what it leaves to fail:

- :func:`drop_empty_unknown_keys`: a key the model does not define reads as absent when its value is empty (``""``,
  ``null``, ``[]``, ``{}``). An unknown key that carries anything still fails — that is content in the wrong place.
- :func:`repair_json_form`: closes an array element left open (``"data": {...}`` followed by ``, {`` or ``]`` where
  ``}}`` was due) and joins a reply split into consecutive objects whose keys do not overlap. The only character
  ever added is the ``}`` the next token implies, and nothing is removed or reordered; any other syntax error is left
  to fail.

Neither touches meaning: required fields stay required, unknown keys with a value stay forbidden, and every value is
still validated by the reply model. The rules are the ones EverOS applies to its picture replies (measured there on
2026-11-11: 7 of 168 DeepSeek V4.1 Flash picture replies failed on exactly these slips, and none said anything a
valid reply would not have).
"""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel

_LITERAL = re.compile(r"-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null")


def is_empty(value: object) -> bool:
    """Whether ``value`` says nothing: ``None``, a blank string, ``[]`` or ``{}``."""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, list | dict):
        return not value
    return False


def drop_empty_unknown_keys(model: type[BaseModel], value: object) -> object:
    """``value`` without the keys ``model`` does not define whose value is empty.

    For a ``model_validator(mode="before")``: anything but a mapping passes through untouched for the model to
    reject. A field is known by its name and by its alias.
    """
    return known_or_filled(model, value) if isinstance(value, dict) else value


def known_or_filled(model: type[BaseModel], value: dict[str, Any]) -> dict[str, Any]:
    """The keys of ``value`` that ``model`` defines (by name or alias), and the others that carry something."""
    known: set[str] = set()
    for name, field in model.model_fields.items():
        known.add(name)
        if field.alias:
            known.add(field.alias)
    return {key: item for key, item in value.items() if key in known or not is_empty(item)}


def repair_json_form(text: str) -> str | None:
    """``text`` with its form slips mended, or ``None`` when it has none it can mend (see the module docstring)."""
    closed = _close_open_elements(text)
    if closed is None:
        return None
    decoder = json.JSONDecoder()
    values: list[object] = []
    at = 0
    while True:
        at = _skip_space(closed, at)
        if at == len(closed):
            break
        try:
            value, at = decoder.raw_decode(closed, at)
        except json.JSONDecodeError:
            return None
        values.append(value)
    if len(values) == 1:
        return closed if closed != text else None
    objects = [value for value in values if isinstance(value, dict)]
    if not objects or len(objects) != len(values):
        return None
    merged: dict[str, object] = {}
    for obj in objects:
        if merged.keys() & obj.keys():
            return None
        merged.update(obj)
    return json.dumps(merged, ensure_ascii=False)


def _skip_space(text: str, at: int) -> int:
    while at < len(text) and text[at] in " \t\r\n":
        at += 1
    return at


def _string_end(text: str, at: int) -> int:
    """Index just past the string opening at ``at``; -1 when it never closes."""
    i = at + 1
    while i < len(text):
        char = text[i]
        if char == "\\":
            i += 2
            continue
        if char == '"':
            return i + 1
        i += 1
    return -1


def _close_open_elements(text: str) -> str | None:  # noqa: C901 — one state machine, read top to bottom
    """``text`` with a ``}`` inserted after each array element left open.

    A stack of open containers, each with what it expects next. Two moments are mended, both inside an object that is
    an array's element: a ``{`` right after a comma (where a key must come, so the comma was the array's and the
    element had ended before it) and a ``]`` right after a complete value (the array closes, so the element had
    ended). Returns ``None`` at any other syntax error, and when containers are still open at the end. The text may
    hold several top-level values; joining them is the caller's.
    """
    stack: list[list[str]] = []  # [kind, expects]; kind "{" or "["
    inserts: list[int] = []
    last_comma = -1
    i = 0
    while i < len(text):
        char = text[i]
        if char in " \t\r\n":
            i += 1
            continue
        top = stack[-1] if stack else None
        in_element = len(stack) >= 2 and stack[-2][0] == "["
        if char == '"':
            end = _string_end(text, i)
            if end < 0:
                return None
            if top is not None:
                if top[0] == "{" and top[1] in ("key_or_end", "key"):
                    top[1] = "colon"
                elif top[1] in ("value", "value_or_end"):
                    top[1] = "comma_or_end"
                else:
                    return None
            i = end
        elif char == ":":
            if top is None or top[0] != "{" or top[1] != "colon":
                return None
            top[1] = "value"
            i += 1
        elif char == ",":
            if top is None or top[1] != "comma_or_end":
                return None
            top[1] = "key" if top[0] == "{" else "value"
            last_comma = i
            i += 1
        elif char in "{[":
            if top is not None and top[0] == "{" and top[1] == "key":
                if char != "{" or not in_element:
                    return None
                inserts.append(last_comma)  # the element ended before the comma
                stack.pop()
                top = stack[-1]
            elif top is not None and top[1] not in ("value", "value_or_end"):
                return None
            if top is not None:
                top[1] = "comma_or_end"  # what the parent expects once this closes
            stack.append([char, "key_or_end" if char == "{" else "value_or_end"])
            i += 1
        elif char == "}":
            if top is None or top[0] != "{" or top[1] not in ("key_or_end", "comma_or_end"):
                return None
            stack.pop()
            i += 1
        elif char == "]":
            if top is not None and top[0] == "{" and top[1] == "comma_or_end" and in_element:
                inserts.append(i)  # the element ended before the array closes
                stack.pop()
                continue
            if top is None or top[0] != "[" or top[1] not in ("value_or_end", "comma_or_end"):
                return None
            stack.pop()
            i += 1
        else:
            match = _LITERAL.match(text, i)
            if match is None or (top is not None and top[1] not in ("value", "value_or_end")):
                return None
            if top is not None:
                top[1] = "comma_or_end"
            i = match.end()
    if stack:
        return None
    for at in sorted(inserts, reverse=True):
        text = f"{text[:at]}}}{text[at:]}"
    return text
