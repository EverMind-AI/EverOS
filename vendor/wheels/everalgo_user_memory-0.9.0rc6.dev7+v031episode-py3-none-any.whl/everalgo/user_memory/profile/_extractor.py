"""``ProfileExtractor``: the two entry paths and the stages each runs, wired from the sibling modules."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from asgiref.sync import async_to_sync

from everalgo.llm import LLMMessage, TextPart
from everalgo.user_memory._language import OutputLanguage, resolve_output_language
from everalgo.user_memory.profile._items import (
    _ITEM_WIDTH_BACKSTOP,
    _LABEL_FIELDS,
    _PROFILE_MAX_ITEMS,
    _PROFILE_MAX_PER_CATEGORY,
    _TRAITS_MAX,
    _dated_buckets,
    _in_group,
    _Item,
    _item_label,
    _normalize,
)
from everalgo.user_memory.profile._lineage import (
    ProfileState,
    Scope,
    apply_consolidation,
    apply_update,
    consolidation_scopes,
    other_names,
    scope_entries,
)
from everalgo.user_memory.profile._merge import (
    _apply_ops,
    _dedupe,
    _identity_key,
    _overcrowded_labels,
    _profile_from_buckets,
    _stored_items,
)
from everalgo.user_memory.profile._render import (
    _normalize_available_categories,
    _render_available_categories,
    _render_episodes,
    _render_group,
    _render_items,
    _render_profile_for_compact,
    _render_profile_for_episode_update,
    _render_segments,
    _render_stored_profile,
    _resolve_episode_target,
    _select_episodes,
    _sender_display_name,
    _user_senders,
)
from everalgo.user_memory.profile._replies import (
    _call_llm_for_memcell_consolidate,
    _call_llm_for_memcell_update,
    _call_llm_for_profile_compact,
    _call_llm_for_profile_init,
    _call_llm_for_profile_regroup,
    _call_llm_for_profile_update,
    _CompactOutput,
    _RegroupOutput,
)
from everalgo.user_memory.profile._result import ProfilePicture, ProfileUpdate
from everalgo.user_memory.profile._stages import (
    _EPISODE_COMPACT,
    _EPISODE_INIT,
    _EPISODE_REGROUP,
    _EPISODE_UPDATE,
    _MEMCELL_CONSOLIDATE,
    _MEMCELL_FIRST_UPDATE,
    _MEMCELL_UPDATE,
    _StagePrompts,
)
from everalgo.user_memory.prompts.en.profile_from_episode_texts import REGROUP_REPLY_SKELETONS
from everalgo.utils import InvalidInputError, tagged

if TYPE_CHECKING:
    from collections.abc import Sequence

    from everalgo.llm.protocols import LLMClient
    from everalgo.types import Episode, MemCell, Profile

# The package's name rather than this module's: hosts collect the log contract under it.
logger = logging.getLogger("everalgo.user_memory.profile")


class ProfileExtractor:
    """Synthesize one owner-scoped Profile from chronological memory inputs.

    ``aupdate`` (and ``aextract``, which returns its profile) reads the MemCells no earlier update has read — normally
    one new segment — with any pictures the target user posted in them, and silently skips non-ChatMessage items: one
    UPDATE call, then a CONSOLIDATE call for each part of the profile over its cap that has grown since it was last
    consolidated. ``aextract_from_episodes`` reads dated generic or reflected Episodes in any order, skips items that
    do not reference the resolved owner, raises only when none reference that owner, and keeps the profile's timeline
    itself: an Episode observed before the stored profile's newest date can add to the profile but never rewrites or
    deletes what a later Episode established.

    Args:
        llm: The client every stage calls.
    """

    def __init__(self, *, llm: LLMClient) -> None:
        self._llm = llm

    async def aextract(
        self,
        memcells: Sequence[MemCell],
        *,
        sender_id: str,
        old_profile: Profile | None = None,
        custom_instructions: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Profile:
        """Extract one Profile for ``sender_id`` from ``memcells``: :meth:`aupdate`'s profile, without its lineage.

        Args:
            memcells: Non-empty and chronological; the conversation no earlier update of ``old_profile`` has read.
            sender_id: One of the memcells' human (``role == "user"``) senders, never an assistant.
            old_profile: The stored profile; None for a person with none yet.
            custom_instructions: As for :meth:`aupdate`.
            output_language: As for :meth:`aupdate`.

        Returns:
            The updated Profile.

        Raises:
            InvalidInputError: As :meth:`aupdate` raises it.
            LLMOutputError: As :meth:`aupdate` raises it.
        """
        update = await self.aupdate(
            memcells,
            sender_id=sender_id,
            old_profile=old_profile,
            custom_instructions=custom_instructions,
            output_language=output_language,
        )
        return update.profile

    extract = async_to_sync(aextract)

    async def aupdate(
        self,
        memcells: Sequence[MemCell],
        *,
        sender_id: str,
        old_profile: Profile | None = None,
        segment_ids: Sequence[str] | None = None,
        pictures: Sequence[ProfilePicture] = (),
        custom_instructions: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> ProfileUpdate:
        """Update ``old_profile`` for ``sender_id`` from the conversation in ``memcells``, and say what changed.

        One UPDATE call reads the stored profile (none on file is an empty profile, so this is also the first
        extraction for a person) and the memcells, and replies with add / modify / deprecate / none operations, each
        naming the segments and pictures it rests on. Then, while the whole profile holds more than 60 items, or a
        category or trait name more than 8, and that part has grown since it was last consolidated, one CONSOLIDATE
        call per such part rewrites it (the whole profile first; a name only when the whole profile was not
        consolidated). Pass only what no earlier update of ``old_profile`` has read: the stored profile already holds
        what the older conversation said, and reading it again re-adds it. Exceptions raised by the LLM client
        propagate unchanged.

        Args:
            memcells: Non-empty and chronological; the last element is the most recent.
            sender_id: One of the memcells' human (``role == "user"``) senders, never an assistant. The prompt
                scopes extraction to this speaker.
            old_profile: The stored profile, as the last update returned it (every key a host attached to an item
                rides through untouched); None for a person with none yet.
            segment_ids: The host's id of each memcell, in the same order, which the lineage reports; None names
                them ``s1``, ``s2`` and so on.
            pictures: Pictures the target user posted in these memcells, each with the label the memcells' text
                gives it as ``[IMAGE: <label>]``. The model reads them with the conversation; nothing else is attached.
            custom_instructions: The host's instructions for every call this makes, added verbatim in an
                ``<additional_requirements>`` block closing the system message. They cannot replace the rules or the
                reply shape. None or a blank string adds nothing.
            output_language: Language to write the profile in, as an :class:`OutputLanguage` member or its value
                in any casing. None lets the first update follow the participants and every later call keep the
                language the profile is written in.

        Returns:
            The updated profile, an :class:`~everalgo.user_memory.profile.ItemOrigin` for each of its items and a
            :class:`~everalgo.user_memory.profile.RetiredItem` for each stored item it no longer holds.

        Raises:
            InvalidInputError: If ``memcells`` is empty, ``sender_id`` is not a user speaker in ``memcells``,
                ``segment_ids`` does not match ``memcells`` one to one, two pictures share a label or an id is
                blank, ``output_language`` names no supported language, or a ChatMessage with text has no timestamp.
            LLMOutputError: If a reply is not a valid UPDATE or CONSOLIDATE reply even read leniently: every
                operation (or every entry) it holds is invalid, or it is not JSON even once its form is mended.
        """
        if not memcells:
            raise InvalidInputError(
                "memcells is empty, there is nothing to extract a profile from: "
                "pass at least one MemCell, or skip the call when a conversation has none"
            )
        user_senders = _user_senders(memcells)
        if sender_id not in user_senders:
            raise InvalidInputError(
                f"sender_id {sender_id!r} is not a user speaker in memcells (user senders: {sorted(user_senders)!r}): "
                "pass the sender_id of a human speaker (role 'user') who appears in the memcells"
            )
        labels = [f"s{position}" for position in range(1, len(memcells) + 1)]
        ids = _segment_ids(segment_ids, labels)
        _check_pictures(pictures)
        language = resolve_output_language(output_language)
        display_name = _sender_display_name(memcells, sender_id)
        stored_explicit, stored_implicit = _dated_buckets(old_profile) if old_profile is not None else ([], [])
        logger.info(
            "extracting profile: mode=%s, %d memcells, %d pictures, existing explicit=%d implicit=%d, "
            "output_language=%s, custom_instructions=%d chars",
            "UPDATE" if stored_explicit or stored_implicit else "FIRST",
            len(memcells),
            len(pictures),
            len(stored_explicit),
            len(stored_implicit),
            language,
            len(custom_instructions or ""),
        )
        state = ProfileState.from_stored(stored_explicit, stored_implicit)
        stage = _MEMCELL_UPDATE if stored_explicit or stored_implicit else _MEMCELL_FIRST_UPDATE
        messages = stage.render(
            custom_instructions=custom_instructions,
            stored_profile=_render_stored_profile(stored_explicit, stored_implicit),
            segments=_render_segments(memcells, labels),
            target_user=display_name,
            target_user_id=sender_id,
            language_rule=stage.language_rule(language),
        )
        reply, refused = await _call_llm_for_memcell_update(self._llm, _with_pictures(messages, pictures))
        observed_at = max(cell.timestamp for cell in memcells)
        counts = apply_update(
            state,
            reply,
            observed_at=observed_at,
            segment_ids=dict(zip(labels, ids, strict=True)),
            picture_ids={picture.label: picture.id for picture in pictures},
        )
        timestamp = max(old_profile.timestamp, observed_at) if old_profile is not None else observed_at
        logger.info(
            "profile memcell update applied: segments=%d pictures=%d observed_at_ms=%d add=%d modify=%d "
            "deprecate=%d none=%d invalid=%d rejected=%d rewrote_description=%d canonicalised=%d "
            "sources_defaulted=%d explicit=%d implicit=%d",
            len(memcells),
            len(pictures),
            observed_at,
            counts.actions["add"],
            counts.actions["modify"],
            counts.actions["deprecate"],
            counts.actions["none"],
            refused,
            counts.rejected,
            counts.rewrote,
            counts.canonicalised,
            counts.sources_defaulted,
            len(state.buckets["explicit_info"]),
            len(state.buckets["implicit_traits"]),
        )
        consolidated = await self._consolidate(
            state,
            consolidated_at=timestamp,
            display_name=display_name,
            sender_id=sender_id,
            output_language=language,
            custom_instructions=custom_instructions,
        )
        profile = _profile_from_buckets(
            owner_id=old_profile.owner_id if old_profile is not None else sender_id,
            timestamp=timestamp,
            explicit_info=state.items("explicit_info"),
            implicit_traits=state.items("implicit_traits"),
        )
        logger.info(
            "profile extracted: mode=%s -> explicit=%d implicit=%d retired=%d consolidated=%d",
            "UPDATE" if stored_explicit or stored_implicit else "FIRST",
            len(profile.explicit_info),
            len(profile.implicit_traits),
            len(state.retired),
            len(consolidated),
        )
        return ProfileUpdate(
            profile=profile,
            explicit_info=state.origins("explicit_info"),
            implicit_traits=state.origins("implicit_traits"),
            retired=state.final_retirements(),
            consolidated=tuple(consolidated),
        )

    update = async_to_sync(aupdate)

    async def _consolidate(
        self,
        state: ProfileState,
        *,
        consolidated_at: int,
        display_name: str,
        sender_id: str,
        output_language: OutputLanguage | None,
        custom_instructions: str | None,
    ) -> list[str]:
        """Consolidate, one call each, the parts :func:`consolidation_scopes` finds; return the scopes it ran."""
        done: list[str] = []
        for scope in consolidation_scopes(state):
            entries = scope_entries(state, scope)
            if not entries:
                continue
            messages = _MEMCELL_CONSOLIDATE.render(
                custom_instructions=custom_instructions,
                scope=_describe_scope(scope, len(entries)),
                other_names=", ".join(other_names(state, scope)) or "(none)",
                items=_render_items([(ref, entry.item) for ref, entry in entries]),
                max_items=_PROFILE_MAX_ITEMS,
                max_per_category=_PROFILE_MAX_PER_CATEGORY,
                max_traits=_TRAITS_MAX,
                target_user=display_name,
                target_user_id=sender_id,
                language_rule=_MEMCELL_CONSOLIDATE.language_rule(output_language),
            )
            reply, refused = await _call_llm_for_memcell_consolidate(self._llm, messages)
            counts = apply_consolidation(state, scope, reply, consolidated_at=consolidated_at)
            logger.info(
                "profile consolidated: scope=%s bucket=%s label_len=%d shown=%d written=%d merged=%d refiled=%d "
                "unchanged=%d dropped=%d refused=%d invalid=%d explicit=%d implicit=%d",
                "profile" if scope.whole else "bucket" if scope.bucket_wide else "name",
                scope.bucket or "-",
                len(scope.label or ""),
                counts.shown,
                counts.written,
                counts.merged,
                counts.refiled,
                counts.unchanged,
                counts.dropped,
                counts.refused,
                refused,
                len(state.buckets["explicit_info"]),
                len(state.buckets["implicit_traits"]),
            )
            done.append(scope.describe())
        return done

    async def aextract_from_episodes(
        self,
        episodes: Sequence[Episode],
        *,
        owner_id: str,
        owner_name: str | None = None,
        old_profile: Profile | None = None,
        categories: Sequence[str] | None = None,
        custom_instructions: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Profile:
        """Extract one owner-scoped Profile from dated Episode narratives.

        Each Episode's ``timestamp`` is the observation date of what it narrates. The batch is ordered by that
        date, and in UPDATE mode split around the stored ``Profile.timestamp``: Episodes observed before it may
        add facts and evidence but never rewrite or delete what a later Episode established; the rest update
        normally. Callers pass whatever Episodes are new to them, in any order. Exceptions raised by the LLM client
        propagate unchanged.

        Args:
            episodes: Non-empty Episodes with non-blank narratives. Items that do not contain the resolved target
                reference are excluded; at least one must contain it.
            owner_id: Authoritative owner identifier written to ``Profile.owner_id``.
            owner_name: Display name used to select narratives about the owner; blank or missing falls back to
                ``owner_id``.
            old_profile: Existing profile for UPDATE; None for INIT.
            categories: Complete current category snapshot for ``explicit_info``, stripped, blanks ignored and
                exact duplicates removed in first-seen order. None or empty lets the model coin categories. It
                does not constrain ``implicit_traits.trait``.
            custom_instructions: The host's instructions for every call this makes, added verbatim as an
                ``<additional_requirements>`` block closing the system message. They cannot replace the rules or the
                output shape. None or a blank string adds nothing.
            output_language: Language to write the profile in. None makes INIT inherit the Episode language and
                UPDATE preserve the existing Profile language.

        Returns:
            The extracted or updated Profile. ``Profile.timestamp`` is the newest observation date seen so far and
            never moves backwards; every item carries ``observed_at``, the observation date of the narrative that
            last established its description.

        Raises:
            TypeError: If an item of ``episodes`` is not an :class:`Episode`, or ``categories`` is not a sequence
                of strings or contains a non-string value.
            InvalidInputError: If owner or Episode validation fails, ``old_profile`` belongs to another owner, or
                ``output_language`` names no supported language.
            LLMOutputError: If a reply is not a valid INIT, UPDATE, COMPACT or REGROUP output.
        """
        target_user = _resolve_episode_target(owner_id, owner_name)
        selected = _select_episodes(episodes, target_user=target_user)
        category_snapshot = _normalize_available_categories(categories)
        available_categories = _render_available_categories(category_snapshot)
        if old_profile is not None and old_profile.owner_id != owner_id:
            raise InvalidInputError(
                f"old_profile.owner_id {old_profile.owner_id!r} does not match owner_id {owner_id!r}: "
                "pass the stored profile of the same owner, or None to start a new one"
            )
        language = resolve_output_language(output_language)

        mode = "INIT" if old_profile is None else "UPDATE"
        logger.info(
            "extracting profile from Episodes: mode=%s, %d/%d matching episodes observed at ms %d..%d, "
            "existing explicit=%d implicit=%d, output_language=%s, categories=%d, custom_instructions=%d chars",
            mode,
            len(selected),
            len(episodes),
            selected[0].timestamp,
            selected[-1].timestamp,
            len(old_profile.explicit_info) if old_profile else 0,
            len(old_profile.implicit_traits) if old_profile else 0,
            language,
            len(category_snapshot),
            len(custom_instructions or ""),
        )
        if old_profile is None:
            result = await self._init_extract_from_episodes(
                selected,
                owner_id=owner_id,
                target_user=target_user,
                available_categories=available_categories,
                custom_instructions=custom_instructions,
                output_language=language,
            )
        else:
            result = await self._update_extract_from_episodes(
                selected,
                owner_id=owner_id,
                target_user=target_user,
                old_profile=old_profile,
                available_categories=available_categories,
                custom_instructions=custom_instructions,
                output_language=language,
            )
        logger.info(
            "profile extracted from Episodes: mode=%s -> explicit=%d implicit=%d",
            mode,
            len(result.explicit_info),
            len(result.implicit_traits),
        )
        return result

    extract_from_episodes = async_to_sync(aextract_from_episodes)

    # ------------------------------------------------------------------
    # Private: INIT path
    # ------------------------------------------------------------------

    async def _init_extract_from_episodes(
        self,
        episodes: Sequence[Episode],
        *,
        owner_id: str,
        target_user: str,
        available_categories: str,
        custom_instructions: str | None,
        output_language: OutputLanguage | str | None,
    ) -> Profile:
        messages = _EPISODE_INIT.render(
            custom_instructions=custom_instructions,
            episode_texts=_render_episodes(episodes),
            target_user=target_user,
            available_categories=available_categories,
            language_rule=_EPISODE_INIT.language_rule(output_language),
        )

        data = await _call_llm_for_profile_init(self._llm, messages, reply=_EPISODE_INIT.reply)
        observed_at = episodes[-1].timestamp
        return _profile_from_buckets(
            owner_id=owner_id,
            timestamp=observed_at,
            explicit_info=_dedupe(
                _stored_items("explicit_info", data["explicit_info"], observed_at), source="episode-init"
            ),
            implicit_traits=_dedupe(
                _stored_items("implicit_traits", data["implicit_traits"], observed_at), source="episode-init"
            ),
        )

    # ------------------------------------------------------------------
    # Private: UPDATE path
    # ------------------------------------------------------------------

    async def _update_extract_from_episodes(
        self,
        episodes: Sequence[Episode],
        *,
        owner_id: str,
        target_user: str,
        old_profile: Profile,
        available_categories: str,
        custom_instructions: str | None,
        output_language: OutputLanguage | str | None,
    ) -> Profile:
        """Run UPDATE in up to two passes: Episodes older than the stored profile first, then the rest.

        Each pass carries one observation date, its newest narrative, which ``_collect_indexed`` judges every
        rewrite against.
        """
        historical = [episode for episode in episodes if episode.timestamp < old_profile.timestamp]
        current = list(episodes[len(historical) :])
        if historical:
            logger.info(
                "profile update split around stored timestamp ms %d: %d historical, %d current narratives",
                old_profile.timestamp,
                len(historical),
                len(current),
            )
        profile = old_profile
        for pass_name, batch in (("historical", historical), ("current", current)):
            if batch:
                profile = await self._update_pass_from_episodes(
                    batch,
                    pass_name=pass_name,
                    owner_id=owner_id,
                    target_user=target_user,
                    old_profile=profile,
                    available_categories=available_categories,
                    custom_instructions=custom_instructions,
                    output_language=output_language,
                )
        return profile

    async def _update_pass_from_episodes(
        self,
        episodes: Sequence[Episode],
        *,
        pass_name: str,
        owner_id: str,
        target_user: str,
        old_profile: Profile,
        available_categories: str,
        custom_instructions: str | None,
        output_language: OutputLanguage | str | None,
    ) -> Profile:
        messages = _EPISODE_UPDATE.render(
            custom_instructions=custom_instructions,
            stored_profile=_render_profile_for_episode_update(old_profile),
            episode_texts=_render_episodes(episodes),
            target_user=target_user,
            available_categories=available_categories,
            language_rule=_EPISODE_UPDATE.language_rule(output_language),
        )

        data = await _call_llm_for_profile_update(self._llm, messages, reply=_EPISODE_UPDATE.reply)
        merged_profile = _apply_ops(
            old_profile, data["operations"], timestamp=episodes[-1].timestamp, pass_name=pass_name
        )
        return await self._maintain_updated_profile(
            merged_profile,
            stored=old_profile,
            display_name=target_user,
            sender_id=owner_id,
            output_language=output_language,
            custom_instructions=custom_instructions,
            compact_prompts=_EPISODE_COMPACT,
            regroup_prompts=_EPISODE_REGROUP,
            available_categories=available_categories,
        )

    async def _maintain_updated_profile(
        self,
        merged_profile: Profile,
        *,
        stored: Profile,
        display_name: str,
        sender_id: str,
        output_language: OutputLanguage | str | None,
        custom_instructions: str | None,
        compact_prompts: _StagePrompts[_CompactOutput],
        regroup_prompts: _StagePrompts[_RegroupOutput],
        available_categories: str | None = None,
    ) -> Profile:
        """COMPACT the whole profile past the total cap, then REGROUP each group still past a per-label cap.

        The per-label check reads COMPACT's result when COMPACT ran, so a group COMPACT left over its cap is
        regrouped in the same call instead of waiting for the next UPDATE. Without a COMPACT it reads what changed
        since ``stored``, the profile this UPDATE was merged into: a group past its cap is regrouped only when it
        grew, since an unchanged one is what the last regroup returned (see ``_overcrowded_labels``).
        """
        profile = merged_profile
        regroup_against: Profile | None = stored
        total_items = len(profile.explicit_info) + len(profile.implicit_traits)
        if total_items > _PROFILE_MAX_ITEMS:
            logger.warning(
                "profile total cap breached (%d > %d items), running full compact",
                total_items,
                _PROFILE_MAX_ITEMS,
            )
            profile = await self._compact(
                profile,
                display_name=display_name,
                sender_id=sender_id,
                output_language=output_language,
                custom_instructions=custom_instructions,
                prompts=compact_prompts,
                available_categories=available_categories,
            )
            regroup_against = None
        return await self._regroup_overcrowded(
            profile,
            stored=regroup_against,
            display_name=display_name,
            sender_id=sender_id,
            output_language=output_language,
            custom_instructions=custom_instructions,
            prompts=regroup_prompts,
            available_categories=available_categories,
        )

    async def _regroup_overcrowded(
        self,
        profile: Profile,
        *,
        stored: Profile | None,
        display_name: str,
        sender_id: str,
        prompts: _StagePrompts[_RegroupOutput],
        custom_instructions: str | None,
        available_categories: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Profile:
        """REGROUP, once each, every group past its per-label cap or holding an item past the width backstop.

        With ``stored``, only for what changed since it (see ``_overcrowded_labels``).
        """
        result = profile
        for bucket, label in _overcrowded_labels(profile.explicit_info, profile.implicit_traits, stored=stored):
            result = await self._regroup(
                result,
                bucket=bucket,
                label=label,
                display_name=display_name,
                sender_id=sender_id,
                output_language=output_language,
                custom_instructions=custom_instructions,
                prompts=prompts,
                available_categories=available_categories,
            )
        return result

    async def _regroup(
        self,
        profile: Profile,
        *,
        bucket: str,
        label: str,
        display_name: str,
        sender_id: str,
        prompts: _StagePrompts[_RegroupOutput],
        custom_instructions: str | None,
        available_categories: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Profile:
        """Reorganise one overcrowded group in place; every other item passes through untouched.

        A reply that still breaches the cap is accepted with a warning: regroup never loops, and the next UPDATE
        regroups the label again only once it has grown.
        """
        wanted = _normalize(label)
        buckets: dict[str, Sequence[_Item]] = {
            "explicit_info": profile.explicit_info,
            "implicit_traits": profile.implicit_traits,
        }
        group = [item for item in buckets[bucket] if _in_group(item, wanted)]
        rest = [item for item in buckets[bucket] if not _in_group(item, wanted)]
        other_labels = sorted({lbl for item in rest if (lbl := _item_label(item)) is not None})
        logger.warning(
            "profile group over cap, regrouping: bucket=%s label_len=%d group_items=%d "
            "(cap %d/label, %d-unit width backstop)",
            bucket,
            len(label),
            len(group),
            _PROFILE_MAX_PER_CATEGORY,
            _ITEM_WIDTH_BACKSTOP,
        )
        messages = prompts.render(
            custom_instructions=custom_instructions,
            bucket=bucket,
            reply_skeleton=REGROUP_REPLY_SKELETONS[bucket],
            label=label,
            label_field=_LABEL_FIELDS[bucket],
            count=len(group),
            max_per_category=_PROFILE_MAX_PER_CATEGORY,
            other_labels=", ".join(other_labels) if other_labels else "(none)",
            items_text=_render_group(group),
            target_user=display_name,
            target_user_id=sender_id,
            available_categories=available_categories or "[]",
            language_rule=prompts.language_rule(output_language),
        )
        data = await _call_llm_for_profile_regroup(self._llm, messages, reply=prompts.reply, bucket=bucket)
        returned: list[dict[str, Any]] = data["items"]
        kept = [item for item in returned if _identity_key(item["description"]) is not None]
        dropped_malformed = len(returned) - len(kept)
        if dropped_malformed:
            logger.warning(
                "profile regroup dropped %d malformed item(s) bucket=%s label_len=%d",
                dropped_malformed,
                bucket,
                len(label),
            )
        # A regrouped item has no traceable origin, so it takes the profile's own date.
        buckets[bucket] = _dedupe([*rest, *_stored_items(bucket, kept, profile.timestamp)], source="regroup")
        still = sum(1 for item in buckets[bucket] if _in_group(item, wanted))
        if still > _PROFILE_MAX_PER_CATEGORY:
            logger.warning(
                "profile regroup left label over cap: bucket=%s label_len=%d count=%d", bucket, len(label), still
            )
        logger.info(
            "profile regroup done: bucket=%s label_len=%d group %d -> %d items",
            bucket,
            len(label),
            len(group),
            len(kept),
        )
        return _profile_from_buckets(
            owner_id=profile.owner_id,
            timestamp=profile.timestamp,
            explicit_info=buckets["explicit_info"],
            implicit_traits=buckets["implicit_traits"],
        )

    async def _compact(
        self,
        profile: Profile,
        *,
        display_name: str,
        sender_id: str,
        prompts: _StagePrompts[_CompactOutput],
        custom_instructions: str | None,
        available_categories: str | None = None,
        output_language: OutputLanguage | str | None = None,
    ) -> Profile:
        total_items = len(profile.explicit_info) + len(profile.implicit_traits)
        messages = prompts.render(
            custom_instructions=custom_instructions,
            total_items=total_items,
            max_items=_PROFILE_MAX_ITEMS,
            max_per_category=_PROFILE_MAX_PER_CATEGORY,
            profile_text=_render_profile_for_compact(profile),
            target_user=display_name,
            target_user_id=sender_id,
            available_categories=available_categories or "[]",
            language_rule=prompts.language_rule(output_language),
        )

        data = await _call_llm_for_profile_compact(self._llm, messages, reply=prompts.reply)
        # A rewritten item cannot be traced to the ones it came from, so it takes the profile's own date.
        new_explicit = _dedupe(
            _stored_items("explicit_info", data["explicit_info"], profile.timestamp), source="compact"
        )
        new_implicit = _dedupe(
            _stored_items("implicit_traits", data["implicit_traits"], profile.timestamp), source="compact"
        )
        logger.info(
            "profile compacted: %d -> %d items",
            total_items,
            len(new_explicit) + len(new_implicit),
        )
        return _profile_from_buckets(
            owner_id=profile.owner_id,
            timestamp=profile.timestamp,
            explicit_info=new_explicit,
            implicit_traits=new_implicit,
        )


def _segment_ids(segment_ids: Sequence[str] | None, labels: Sequence[str]) -> list[str]:
    """The host's id of each segment, or the labels themselves when the host names none.

    Raises:
        InvalidInputError: If ``segment_ids`` is not one non-blank id per memcell.
    """
    if segment_ids is None:
        return list(labels)
    ids = [str(value) for value in segment_ids]
    if len(ids) != len(labels) or any(not value.strip() for value in ids):
        raise InvalidInputError(
            f"segment_ids must name each of the {len(labels)} memcells with a non-blank id, in order: "
            f"got {len(ids)} ids; pass one id per memcell, or None to let the update name them s1, s2, ..."
        )
    return ids


def _check_pictures(pictures: Sequence[ProfilePicture]) -> None:
    """Raise unless every picture has a label of its own and a non-blank id.

    Raises:
        InvalidInputError: Naming the first offending position.
    """
    seen: set[str] = set()
    for position, picture in enumerate(pictures):
        if not picture.label.strip() or not picture.id.strip() or picture.label in seen:
            raise InvalidInputError(
                f"pictures[{position}] needs a label of its own and a non-blank id: give each picture the label the "
                "conversation text uses for it ([IMAGE: <label>]) and the host's id for it"
            )
        seen.add(picture.label)


def _with_pictures(messages: list[LLMMessage], pictures: Sequence[ProfilePicture]) -> list[LLMMessage]:
    """``messages`` with ``pictures`` attached after the user message's text, each after its ``<picture>`` element."""
    if not pictures:
        return messages
    *head, user = messages
    text = user.content if isinstance(user.content, str) else ""
    names = ", ".join(picture.label for picture in pictures)
    parts: list[Any] = [TextPart(text=f"{text}\n\n{tagged('pictures', f'Attached in order: {names}.')}")]
    for picture in pictures:
        parts.append(TextPart(text=tagged("picture", f"label: {picture.label}")))
        parts.append(picture.part)
    return [*head, LLMMessage(role="user", content=parts)]


def _describe_scope(scope: Scope, count: int) -> str:
    """What ``<scope>`` tells the model: which part is over which cap, with how many items."""
    if scope.whole:
        return (
            f"The whole profile: {count} items, against a cap of {_PROFILE_MAX_ITEMS} in all, {_TRAITS_MAX} traits "
            f"and {_PROFILE_MAX_PER_CATEGORY} under any one name."
        )
    if scope.bucket_wide:
        return (
            f"Every implicit_traits item: {count} traits, against a cap of {_TRAITS_MAX} traits and "
            f"{_PROFILE_MAX_PER_CATEGORY} under any one name. Traits that state one disposition under different "
            "names are restatements to merge."
        )
    field = _LABEL_FIELDS[scope.bucket or "explicit_info"]
    return (
        f'The {scope.bucket} items filed under the {field} name "{scope.label}": {count} items, against a cap of '
        f"{_PROFILE_MAX_PER_CATEGORY} under one name."
    )
