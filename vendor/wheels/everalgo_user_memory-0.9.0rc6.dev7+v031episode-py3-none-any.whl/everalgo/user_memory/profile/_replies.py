"""Each stage's reply model, the shape its prompt's output skeleton shows, and the LLM callsites held to it.

Each callsite makes one call and validates the reply against its stage's output model; there is no retry here,
the host decides (``docs/concepts/llm-contract.md`` §4, §5). The Episode path's replies are strict as written. The
MemCell path's two replies are read leniently in form and strictly in meaning (:mod:`._reply_form`): a form slip is
mended, an unknown key left empty reads as absent, and an operation or item that is invalid on its own is left out
rather than failing the reply — the reply fails only when every one it holds is invalid. Their JSON schema is
unchanged by any of it.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Annotated, Any, Literal, Self

from pydantic import Field, TypeAdapter, ValidationError, model_validator

from everalgo.llm import LLMMessage, LLMOutputError, StrictOutputModel, describe_errors, parse_reply
from everalgo.user_memory.profile._reply_form import drop_empty_unknown_keys, known_or_filled, repair_json_form

if TYPE_CHECKING:
    from everalgo.llm.protocols import LLMClient


class _ExplicitItem(StrictOutputModel):
    """An ``explicit_info`` item as every stage writes it, grounding first: ``{"evidence", "description", "category"}``."""

    evidence: str
    description: str
    category: str


class _ImplicitTrait(StrictOutputModel):
    """An ``implicit_traits`` item as every stage writes it, grounding first: ``{"basis", "description", "trait"}``."""

    basis: str
    description: str
    trait: str


class _ProfileItems(StrictOutputModel):
    """INIT reply: the ``{"explicit_info", "implicit_traits"}`` skeleton of both INIT prompts."""

    explicit_info: list[_ExplicitItem]
    implicit_traits: list[_ImplicitTrait]


class _CompactOutput(StrictOutputModel):
    """COMPACT reply on the Episode path: the rewritten buckets, nothing else."""

    explicit_info: list[_ExplicitItem]
    implicit_traits: list[_ImplicitTrait]


class _RegroupOutput(StrictOutputModel):
    """REGROUP reply on the Episode path: the group's kept items, nothing else."""

    items: list[_ExplicitItem | _ImplicitTrait]


_Bucket = Literal["explicit_info", "implicit_traits"]
# The item shape each bucket holds; the business checks after parsing hold replies to it.
_BUCKET_SHAPES: dict[str, type[_ExplicitItem | _ImplicitTrait]] = {
    "explicit_info": _ExplicitItem,
    "implicit_traits": _ImplicitTrait,
}


class _AddOp(StrictOutputModel):
    """UPDATE ``add`` operation: a new item for the bucket named by its ``type`` key."""

    action: Literal["add"]
    # The JSON key stays "type", as the UPDATE prompts show it; the field name avoids the builtin.
    bucket: _Bucket = Field(alias="type")
    data: _ExplicitItem | _ImplicitTrait


class _UpdateOp(StrictOutputModel):
    """UPDATE ``update`` operation: the item at ``index`` restated in full."""

    action: Literal["update"]
    bucket: _Bucket = Field(alias="type")
    index: int
    data: _ExplicitItem | _ImplicitTrait


class _DeleteOp(StrictOutputModel):
    """UPDATE ``delete`` operation: the item at ``index`` removed, with the model's ``reason``."""

    action: Literal["delete"]
    bucket: _Bucket = Field(alias="type")
    index: int
    reason: str


class _NoneOp(StrictOutputModel):
    """UPDATE ``none`` operation: the documented no-op."""

    action: Literal["none"]


_Operation = Annotated[_AddOp | _UpdateOp | _DeleteOp | _NoneOp, Field(discriminator="action")]


class _UpdateOutput(StrictOutputModel):
    """UPDATE reply on the Episode path: the ``{"operations"}`` skeleton of its prompt."""

    operations: list[_Operation]


# The MemCell path's two replies: an update's item operations, and a consolidation's rewritten items.

# Keys the extractor writes on stored items and never shows the model; one echoed back into an item says nothing.
_INTERNAL_ITEM_KEYS = frozenset({"observed_at", "consolidated_at"})


def _as_list(value: object) -> object:
    """``None`` as an empty list and one string as a list of it; anything else unchanged, for the model to judge."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return value


def _lenient_op_form(model: type[StrictOutputModel], value: object, *, lists: tuple[str, ...]) -> object:
    """An operation or consolidated item as its model reads it: the form slips of a JSON-mode reply set aside.

    An unknown key left empty reads as absent; each of ``lists`` reads ``null`` or a missing key as an empty list
    and one string as a list of it; ``data`` loses the keys the extractor writes on stored items, which the prompt
    never shows; and a ``ref`` written as a number is read as text, for the merge to resolve or refuse.
    """
    if not isinstance(value, dict):
        return value
    form = known_or_filled(model, value)
    for key in lists:
        form[key] = _as_list(form.get(key))
    data = form.get("data")
    if isinstance(data, dict):
        form["data"] = {key: item for key, item in data.items() if key not in _INTERNAL_ITEM_KEYS}
    ref = form.get("ref")
    if isinstance(ref, int) and not isinstance(ref, bool):
        form["ref"] = ref = str(ref)
    named = _REF_BUCKETS.get(_ref_letter(ref)) if isinstance(ref, str) else None
    if "ref" in model.model_fields and named is not None and form.get("type") == named:
        del form["type"]  # the bucket a ref already names, written out again
    return form


_REF_BUCKETS = {"e": "explicit_info", "t": "implicit_traits"}


def _ref_letter(ref: str) -> str:
    """The bucket letter a ref opens with, brackets, spaces and case set aside."""
    return ref.strip().strip("[]").strip().lower()[:1]


class _AddItemOp(StrictOutputModel):
    """An update's ``add``: a new item for the bucket ``type`` names, with the segments and pictures it rests on."""

    action: Literal["add"]
    bucket: _Bucket = Field(alias="type")
    data: _ExplicitItem | _ImplicitTrait
    sources: list[str]
    pictures: list[str]

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=("sources", "pictures"))


class _ModifyItemOp(StrictOutputModel):
    """An update's ``modify``: the item ``ref`` names, restated in full, with what the new value rests on."""

    action: Literal["modify"]
    ref: str
    data: _ExplicitItem | _ImplicitTrait
    sources: list[str]
    pictures: list[str]

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=("sources", "pictures"))


class _DeprecateItemOp(StrictOutputModel):
    """An update's ``deprecate``: the item ``ref`` names is no longer true, for ``reason``, on ``sources``."""

    action: Literal["deprecate"]
    ref: str
    reason: str
    sources: list[str]

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=("sources",))


class _NoChangeOp(StrictOutputModel):
    """An update's ``none``: nothing in the conversation changes the profile."""

    action: Literal["none"]

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return drop_empty_unknown_keys(cls, value)


_ItemOperation = Annotated[_AddItemOp | _ModifyItemOp | _DeprecateItemOp | _NoChangeOp, Field(discriminator="action")]
_ITEM_OPERATION: TypeAdapter[_AddItemOp | _ModifyItemOp | _DeprecateItemOp | _NoChangeOp] = TypeAdapter(_ItemOperation)


class _ProfileUpdateReply(StrictOutputModel):
    """The MemCell update reply: the ``{"operations"}`` skeleton of its prompt."""

    operations: list[_ItemOperation]

    @classmethod
    def model_validate_json(cls, json_data: str | bytes | bytearray, **kwargs: Any) -> Self:
        """Validate a reply as :func:`read_update_reply` does, so a host checking it reads what the operator reads."""
        del kwargs  # the reply is read one way only
        return read_update_reply(json_data, cls)[0]


class _ConsolidatedExplicit(StrictOutputModel):
    """A consolidated ``explicit_info`` item: the refs it came from, then the item, grounding first."""

    from_refs: list[str] = Field(alias="from")
    evidence: str
    description: str
    category: str

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=("from",))


class _ConsolidatedTrait(StrictOutputModel):
    """A consolidated ``implicit_traits`` item: the refs it came from, then the item, grounding first."""

    from_refs: list[str] = Field(alias="from")
    basis: str
    description: str
    trait: str

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=("from",))


class _DroppedItem(StrictOutputModel):
    """An item a consolidation drops, and why."""

    ref: str
    reason: str

    @model_validator(mode="before")
    @classmethod
    def _read_form(cls, value: object) -> object:
        return _lenient_op_form(cls, value, lists=())


_ConsolidatedItem = _ConsolidatedExplicit | _ConsolidatedTrait
_CONSOLIDATED_ITEM: TypeAdapter[_ConsolidatedItem] = TypeAdapter(_ConsolidatedItem)
_DROPPED_ITEM: TypeAdapter[_DroppedItem] = TypeAdapter(_DroppedItem)


class _ConsolidateReply(StrictOutputModel):
    """The MemCell consolidation reply: the items its changes write and the items it drops; the rest stays as it is."""

    changes: list[_ConsolidatedItem]
    dropped: list[_DroppedItem]

    @classmethod
    def model_validate_json(cls, json_data: str | bytes | bytearray, **kwargs: Any) -> Self:
        """Validate a reply as :func:`read_consolidate_reply` does."""
        del kwargs  # the reply is read one way only
        return read_consolidate_reply(json_data, cls)[0]


def _load_reply(model: type[StrictOutputModel], json_data: str | bytes | bytearray) -> object:
    """The reply's JSON value, its form slips mended first when it does not parse.

    Raises:
        ValidationError: The text is not JSON and :func:`repair_json_form` cannot mend it — the error ``model``
            raises for it, ``json_invalid``.
    """
    text = json_data if isinstance(json_data, str) else bytes(json_data).decode()
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        mended = repair_json_form(text)
        if mended is None:
            raise ValidationError.from_exception_data(
                model.__name__, [{"type": "json_invalid", "loc": (), "input": text, "ctx": {"error": exc.msg}}]
            ) from exc
        return json.loads(mended)


def _valid_elements[T](adapter: TypeAdapter[T], values: object) -> tuple[list[T], int]:
    """Each element of ``values`` that ``adapter`` accepts, and how many it refused; ``values`` must be a list."""
    kept: list[T] = []
    refused = 0
    for value in values if isinstance(values, list) else []:
        try:
            kept.append(adapter.validate_python(value))
        except ValidationError:
            refused += 1
    return kept, refused


def read_update_reply[R: _ProfileUpdateReply](json_data: str | bytes | bytearray, model: type[R]) -> tuple[R, int]:
    """An update reply with its invalid operations left out, and how many were.

    Raises:
        ValidationError: The reply is not JSON even once mended, is not an object holding an ``operations`` list
            and nothing else, or holds operations of which none is valid.
    """
    value = _load_reply(model, json_data)
    try:
        return model.model_validate(value), 0
    except ValidationError:
        if not isinstance(value, dict) or set(known_or_filled(model, value)) != {"operations"}:
            raise
        ops, refused = _valid_elements(_ITEM_OPERATION, value.get("operations"))
        if not ops:
            raise
        return model.model_construct(operations=ops), refused


def read_consolidate_reply[R: _ConsolidateReply](json_data: str | bytes | bytearray, model: type[R]) -> tuple[R, int]:
    """A consolidation reply with its invalid items and drops left out, and how many were.

    The list of written items was called ``items`` before 0.9.0rc6.dev2; a reply that still names it so is read
    as ``changes``.

    Raises:
        ValidationError: The reply is not JSON even once mended, is not an object holding the ``changes`` and
            ``dropped`` lists and nothing else, or holds entries of which none is valid.
    """
    value = _load_reply(model, json_data)
    if isinstance(value, dict) and "items" in value and "changes" not in value:
        value = {("changes" if key == "items" else key): entry for key, entry in value.items()}
    try:
        return model.model_validate(value), 0
    except ValidationError:
        if not isinstance(value, dict):
            raise
        form = known_or_filled(model, value)
        if not set(form) <= {"changes", "dropped"} or not isinstance(form.get("changes", []), list):
            raise
        changes, refused_changes = _valid_elements(_CONSOLIDATED_ITEM, form.get("changes", []))
        dropped, refused_drops = _valid_elements(_DROPPED_ITEM, form.get("dropped", []))
        if not changes and not dropped:
            raise
        return model.model_construct(changes=changes, dropped=dropped), refused_changes + refused_drops


async def _call_llm_for_profile_init(
    llm: LLMClient, messages: list[LLMMessage], *, reply: type[_ProfileItems]
) -> dict[str, Any]:
    """Request an INIT reply and return it validated, dumped to a dict.

    Raises:
        LLMOutputError: If the reply is not a valid INIT output.
    """
    text = await llm.achat(messages=messages, response_format=reply)
    return parse_reply(reply, text, operator="profile init").model_dump(by_alias=True)


async def _call_llm_for_profile_update(
    llm: LLMClient, messages: list[LLMMessage], *, reply: type[_UpdateOutput]
) -> dict[str, Any]:
    """Request an UPDATE reply and return it validated, dumped to a dict whose ``operations`` keep their ``type`` key.

    Raises:
        LLMOutputError: If the reply is not a valid UPDATE output, or an add or update carries an item not shaped
            for the bucket its ``type`` names.
    """
    text = await llm.achat(messages=messages, response_format=reply)
    output = parse_reply(reply, text, operator="profile update")
    _check_bucket_shapes(output)
    return output.model_dump(by_alias=True)


async def _call_llm_for_profile_compact(
    llm: LLMClient, messages: list[LLMMessage], *, reply: type[_CompactOutput]
) -> dict[str, Any]:
    """Request a COMPACT reply and return it validated, dumped to a dict.

    Raises:
        LLMOutputError: If the reply is not a valid COMPACT output.
    """
    text = await llm.achat(messages=messages, response_format=reply)
    return parse_reply(reply, text, operator="profile compact").model_dump(by_alias=True)


async def _call_llm_for_profile_regroup(
    llm: LLMClient, messages: list[LLMMessage], *, reply: type[_RegroupOutput], bucket: str
) -> dict[str, Any]:
    """Request a REGROUP reply for a group of ``bucket`` and return it validated, dumped to a dict.

    Raises:
        LLMOutputError: If the reply is not a valid REGROUP output, or an item is not shaped for ``bucket``.
    """
    text = await llm.achat(messages=messages, response_format=reply)
    output = parse_reply(reply, text, operator="profile regroup")
    _check_item_shapes(output, bucket=bucket)
    return output.model_dump(by_alias=True)


def _check_bucket_shapes(output: _UpdateOutput) -> None:
    """Reject an add or update whose item is not shaped for the bucket its ``type`` names (llm-contract §4.1).

    Raises:
        LLMOutputError: Naming each mismatched operation by position, its bucket and the shape it carried.
    """
    mismatches = [
        f"operations.{position}: {op.action} into {op.bucket} carries a {type(op.data).__name__}"
        for position, op in enumerate(output.operations)
        if isinstance(op, _AddOp | _UpdateOp) and not isinstance(op.data, _BUCKET_SHAPES[op.bucket])
    ]
    if mismatches:
        raise LLMOutputError(f"profile update reply puts items in the wrong bucket: {'; '.join(mismatches)}")


def _check_item_shapes(output: _RegroupOutput, *, bucket: str) -> None:
    """Reject a regrouped item that is not shaped for the group's bucket; regroup never moves an item across.

    Raises:
        LLMOutputError: Naming each mismatched item by position and the shape it carried.
    """
    expected = _BUCKET_SHAPES[bucket]
    mismatches = [
        f"items.{position}: a {type(item).__name__}"
        for position, item in enumerate(output.items)
        if not isinstance(item, expected)
    ]
    if mismatches:
        raise LLMOutputError(
            f"profile regroup reply for a {bucket} group holds items not shaped as {expected.__name__}: "
            f"{'; '.join(mismatches)}"
        )


async def _call_llm_for_memcell_update(llm: LLMClient, messages: list[LLMMessage]) -> tuple[_ProfileUpdateReply, int]:
    """Request a MemCell update reply; return it read leniently, and how many of its operations were invalid.

    Raises:
        LLMOutputError: If the reply is not an update reply even read leniently (see :func:`read_update_reply`).
    """
    text = await llm.achat(messages=messages, response_format=_ProfileUpdateReply)
    try:
        return read_update_reply(text, _ProfileUpdateReply)
    except ValidationError as exc:
        raise LLMOutputError(
            f"profile update reply is not a valid {_ProfileUpdateReply.__name__}: {describe_errors(exc)}"
        ) from exc


async def _call_llm_for_memcell_consolidate(
    llm: LLMClient, messages: list[LLMMessage]
) -> tuple[_ConsolidateReply, int]:
    """Request a consolidation reply; return it read leniently, and how many of its entries were invalid.

    Raises:
        LLMOutputError: If the reply is not a consolidation reply even read leniently.
    """
    text = await llm.achat(messages=messages, response_format=_ConsolidateReply)
    try:
        return read_consolidate_reply(text, _ConsolidateReply)
    except ValidationError as exc:
        raise LLMOutputError(
            f"profile consolidate reply is not a valid {_ConsolidateReply.__name__}: {describe_errors(exc)}"
        ) from exc
