"""Synthesize a user Profile from chronological MemCells or dated Episodes, keeping the profile's timeline.

Design rationale and measurements: ``docs/concepts/profile-design-notes.md``. Modules, each importing only those
below it: ``_extractor`` (:class:`ProfileExtractor`) wires ``_stages`` (prompt templates per stage, over
``_replies``: reply models and LLM callsites, which read the MemCell path's replies through ``_reply_form``),
``_render`` (what the model is shown), ``_merge`` (the Episode path's UPDATE ops, dedupe, the stored profile) and
``_lineage`` (the MemCell path's operations and consolidations, each item's lineage kept, over ``_merge``);
``_items`` holds the stored-item vocabulary and ``_result`` the MemCell path's public input and result types.

The MemCell path (:meth:`ProfileExtractor.aupdate`) has two prompts: UPDATE reads the stored profile and only the new
conversation (with the pictures the target user posted in it) and replies with ``add`` / ``modify`` / ``deprecate``
/ ``none`` operations naming their segments and pictures; CONSOLIDATE rewrites the whole profile, or the items under
one name, once that part is over its cap and has grown since it was last consolidated. The Episode path
(:meth:`ProfileExtractor.aextract_from_episodes`) keeps INIT, UPDATE, COMPACT and REGROUP.

Log lines:
    The lines below are a contract: each starts with ``profile <event>:`` followed by space-separated
    ``key=value`` pairs, and none carries a prompt, a model output or an item's content — only counts, dates
    (epoch ms), lengths and enum values. ``reason`` is the one value with spaces; it runs to the next
    `` key=`` or the end of the line. Every line is logged on ``everalgo.user_memory.profile``, whichever
    module writes it.

    ``profile memcell update applied: segments= pictures= observed_at_ms= add= modify= deprecate= none= invalid=
    rejected= rewrote_description= canonicalised= sources_defaulted= explicit= implicit=`` (INFO)
        Once per MemCell update. ``add`` / ``modify`` / ``deprecate`` / ``none`` count the reply's valid ops by
        action, ``invalid`` the ops left out because they were invalid on their own, ``rejected`` the valid ops
        refused against the profile (unknown ref, wrong shape, already on file, stale). ``rewrote_description``
        counts the modifies that gave an item a new value, ``sources_defaulted`` the ops that named no segment the
        call showed and so rest on all of them. ``explicit`` / ``implicit`` are the bucket sizes before any
        consolidation.
    ``profile consolidated: scope= bucket= label_len= shown= written= merged= refiled= unchanged= dropped= refused=
    invalid= explicit= implicit=`` (INFO)
        Once per consolidation. ``scope`` is ``profile``, ``bucket`` (every trait) or ``name`` (then ``bucket`` and
        ``label_len`` name the part); ``written`` items replaced the items their ``from`` named, ``merged`` of them more than one;
        ``refiled`` items only took a new name, ``unchanged`` ones were restated as they were (output spent on
        nothing); ``refused`` entries named nothing shown in their bucket.
    ``profile over its total cap but not grown since its last consolidation, skipped: count= new=`` (INFO)
    ``profile traits over their cap but not grown since their last consolidation, skipped: count= new=`` (INFO)
    ``profile group over cap but not grown since its last consolidation, skipped: bucket= label_len= count= new=``
    (INFO)
        A part over its cap that has not grown enough since it was last consolidated (15 items for the whole
        profile, 3 for the traits, 4 for one name); the MemCell path consolidates it again only once it has.
    ``profile update applied: pass= observed_at_ms= add= update= delete= none= rejected= rewrote_description=
    history_appended= grounding_only= canonicalised= profile_timestamp_ms=<old>-><new> explicit= implicit=`` (INFO)
        Once per Episode-path UPDATE pass. ``pass`` is ``historical`` or ``current`` for the two halves of an Episode
        batch split around the stored timestamp.
        ``observed_at_ms`` is the date the pass's ops are judged against. ``add`` / ``update`` / ``delete`` /
        ``none`` count the reply's ops by action; ``rejected`` counts the ops refused, where the updates to an
        index the same reply deletes count once. Of the updates that land — several on one index merge into one —
        ``rewrote_description`` restate the fact, ``history_appended`` come from a pass older than their item and
        add earlier history in a parenthesis after its description (the item keeps its ``observed_at``), and
        ``grounding_only`` only add evidence or basis.
        ``canonicalised`` counts adds whose label was respelled to one already on file. ``explicit`` /
        ``implicit`` are the merged bucket sizes, before any COMPACT or REGROUP.
    ``profile update op rejected: action= type= index= reason=`` (WARNING)
        One per refused op; on the MemCell path ``ref_len=`` stands in for ``index=`` where the ref named nothing,
        and ``type=`` names the bucket. A stale rewrite, delete or deprecation appends its criterion:
        ``reason=stale evidence item_observed_at_ms= batch_observed_at_ms=``.
    ``profile add label canonicalised: bucket= from_len= to_len=`` (DEBUG)
        One per respelled add label; lengths only, the label being model-written text.
    ``profile duplicates dropped: source= count=`` (WARNING)
        One per deduplicated list that lost items; ``source`` is ``init``, ``episode-init``, ``update``,
        ``compact`` or ``regroup``.
    ``profile group over cap but not grown since the stored profile, regroup skipped: bucket= label_len= count=
    stored_count=`` (INFO)
        One per group an UPDATE leaves past its per-label cap without growing it: the stored profile holds what the
        last REGROUP returned, so the group goes back to REGROUP only once it grows (or after a COMPACT).

    The Episode-path entry line, ``extracting profile from Episodes: ...``, carries ``categories=``, the size of
    the caller's category snapshot after normalisation. Both entry lines log ``output_language`` once it is
    validated, as the :class:`OutputLanguage` member's value or ``None``. The REGROUP lines name the group by
    ``bucket`` and ``label_len``, never by the label's text.
"""

from __future__ import annotations

__all__ = ["ItemOrigin", "ProfileExtractor", "ProfilePicture", "ProfileUpdate", "RetiredItem"]

from everalgo.user_memory.profile._extractor import ProfileExtractor
from everalgo.user_memory.profile._result import ItemOrigin, ProfilePicture, ProfileUpdate, RetiredItem
