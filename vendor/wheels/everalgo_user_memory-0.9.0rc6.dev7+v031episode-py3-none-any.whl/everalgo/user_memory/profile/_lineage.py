"""The MemCell path's merge: an update's operations and a consolidation's rewrite, each item's lineage kept.

Every item of the profile being built travels as a :class:`_Working` entry carrying how it came to be (the
:class:`~._result.ItemOrigin` fields) and, once a consolidation rewrites or drops it, what it became. An update
validates every operation against the profile as the model was shown it before applying any (the Episode path's
"collect, then apply"), and a consolidation resolves every ``from`` against the items it showed. Nothing is ever
removed by omission: an item leaves the profile only through a ``deprecate``, a ``modify`` that gives it a new
value, a consolidated item that names it in ``from``, or a consolidation's ``dropped``.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from everalgo.types import ExplicitInfoItem, ImplicitTraitItem
from everalgo.user_memory.profile._items import (
    _CATEGORY_GROWTH,
    _CONSOLIDATED_AT,
    _ITEM_WIDTH_BACKSTOP,
    _LABEL_FIELDS,
    _OBSERVED_AT,
    _PROFILE_GROWTH,
    _PROFILE_MAX_ITEMS,
    _PROFILE_MAX_PER_CATEGORY,
    _TRAITS_GROWTH,
    _TRAITS_MAX,
    _Item,
    _item_label,
    _label,
    _normalize,
)
from everalgo.user_memory.profile._merge import _changes_description, _identity_key, _patched, _stale_since
from everalgo.user_memory.profile._render import _item_ref, _parse_ref
from everalgo.user_memory.profile._replies import (
    _AddItemOp,
    _ConsolidatedExplicit,
    _ConsolidatedItem,
    _ConsolidateReply,
    _DeprecateItemOp,
    _ExplicitItem,
    _ImplicitTrait,
    _ModifyItemOp,
    _ProfileUpdateReply,
)
from everalgo.user_memory.profile._result import ItemOrigin, RetiredItem
from everalgo.utils import ascii_width

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping, Sequence

    from everalgo.user_memory.profile._result import Bucket, Change, ItemRef, Retirement

# The package's name rather than this module's: hosts collect the log contract under it.
logger = logging.getLogger("everalgo.user_memory.profile")

BUCKETS: tuple[Bucket, ...] = ("explicit_info", "implicit_traits")
_ITEM_MODELS: dict[Bucket, type[_Item]] = {"explicit_info": ExplicitInfoItem, "implicit_traits": ImplicitTraitItem}
_REPLY_SHAPES: dict[Bucket, type[_ExplicitItem | _ImplicitTrait]] = {
    "explicit_info": _ExplicitItem,
    "implicit_traits": _ImplicitTrait,
}


@dataclass(eq=False)
class _Working:
    """One item of the profile being built, and its lineage.

    ``stored`` is the item as the call was given it, for an entry that stands for one stored item (kept, or given
    fresh evidence) not yet retired; ``successors`` stays None while the entry is in the profile, and a consolidation
    sets it to what replaced the entry (the items it was merged or split into, or nothing when it was dropped).
    """

    item: _Item
    change: Change
    from_items: tuple[ItemRef, ...] = ()
    sources: tuple[str, ...] = ()
    pictures: tuple[str, ...] = ()
    stored: _Item | None = None
    successors: list[_Working] | None = None


@dataclass(eq=False)
class _Retirement:
    """A stored item taken out, its successors still working entries until the profile is final."""

    ref: ItemRef
    item: _Item
    change: Retirement
    reason: str = ""
    sources: tuple[str, ...] = ()
    replaced_by: list[_Working] = field(default_factory=list)


@dataclass(eq=False)
class ProfileState:
    """The profile being built: each bucket's working entries, and the stored items retired so far."""

    buckets: dict[Bucket, list[_Working]]
    retired: list[_Retirement] = field(default_factory=list)

    @classmethod
    def from_stored(cls, explicit_info: Sequence[_Item], implicit_traits: Sequence[_Item]) -> ProfileState:
        """Every stored item, kept, in stored order."""
        given: dict[Bucket, Sequence[_Item]] = {"explicit_info": explicit_info, "implicit_traits": implicit_traits}
        return cls(
            buckets={
                bucket: [_Working(item, "kept", ((bucket, i),), stored=item) for i, item in enumerate(given[bucket])]
                for bucket in BUCKETS
            }
        )

    def items(self, bucket: Bucket) -> list[_Item]:
        """The bucket's items, in order."""
        return [entry.item for entry in self.buckets[bucket]]

    def origins(self, bucket: Bucket) -> tuple[ItemOrigin, ...]:
        """One origin per item of the bucket, in order."""
        return tuple(
            ItemOrigin(change=e.change, from_items=e.from_items, sources=e.sources, pictures=e.pictures)
            for e in self.buckets[bucket]
        )

    def final_retirements(self) -> tuple[RetiredItem, ...]:
        """The retirements, each successor resolved to its place in the final profile."""
        place = {id(e): (bucket, i) for bucket in BUCKETS for i, e in enumerate(self.buckets[bucket])}
        return tuple(
            RetiredItem(
                ref=r.ref,
                item=r.item,
                change=r.change,
                reason=r.reason,
                sources=r.sources,
                replaced_by=tuple(dict.fromkeys(place[id(e)] for e in _alive(r.replaced_by) if id(e) in place)),
            )
            for r in self.retired
        )

    def retire(self, entry: _Working, change: Retirement, *, reason: str = "", by: Sequence[_Working] = ()) -> None:
        """Retire the stored item ``entry`` stands for, unless it stands for none.

        An entry stands for no stored item when this call added it, wrote it in a consolidation, or gave it a new
        value — that value's own retirement already names the entry, and resolves through it to its successors.
        """
        if entry.stored is None:
            return
        self.retired.append(_Retirement(entry.from_items[0], entry.stored, change, reason, (), list(by)))
        entry.stored = None


def _alive(entries: Iterable[_Working]) -> list[_Working]:
    """What ``entries`` became: themselves while in the profile, else whatever replaced them, recursively."""
    out: list[_Working] = []
    for entry in entries:
        out.extend([entry] if entry.successors is None else _alive(entry.successors))
    return out


def _union[T](*groups: Iterable[T]) -> tuple[T, ...]:
    """Every value of ``groups``, once each, in first-seen order."""
    return tuple(dict.fromkeys(value for group in groups for value in group))


# --------------------------------------------------------------------------------------------------
# Update
# --------------------------------------------------------------------------------------------------


@dataclass
class UpdateCounts:
    """What one update reply did, for the ``profile memcell update applied`` line."""

    actions: Counter[str] = field(default_factory=Counter[str])
    rejected: int = 0
    rewrote: int = 0
    canonicalised: int = 0
    sources_defaulted: int = 0


@dataclass
class _Queued:
    data: dict[str, Any]
    sources: tuple[str, ...]
    pictures: tuple[str, ...]


class _UpdatePlan:
    """An update reply's operations, validated against the profile as shown and queued, before any applies."""

    def __init__(
        self,
        state: ProfileState,
        *,
        observed_at: int,
        segment_ids: Mapping[str, str],
        picture_ids: Mapping[str, str],
    ) -> None:
        self.shown = {bucket: list(state.buckets[bucket]) for bucket in BUCKETS}
        self.held: dict[Bucket, set[str]] = {
            bucket: {key for e in entries if (key := _identity_key(e.item.description)) is not None}
            for bucket, entries in self.shown.items()
        }
        self.adds: dict[Bucket, list[_Queued]] = {bucket: [] for bucket in BUCKETS}
        self.patches: dict[ItemRef, _Queued] = {}
        self.deprecations: dict[ItemRef, tuple[str, tuple[str, ...]]] = {}
        self.counts = UpdateCounts()
        self._observed_at = observed_at
        self._segment_ids = segment_ids
        self._picture_ids = picture_ids

    def sources(self, labels: Sequence[str]) -> tuple[str, ...]:
        """The host ids of the segments ``labels`` name; every segment of the call when they name none it showed."""
        resolved = _union(self._segment_ids[x.strip()] for x in labels if x.strip() in self._segment_ids)
        if not resolved:
            self.counts.sources_defaulted += 1
            return _union(self._segment_ids.values())
        return resolved

    def pictures(self, labels: Sequence[str]) -> tuple[str, ...]:
        """The host ids of the pictures ``labels`` name; a label the call did not attach is left out."""
        return _union(self._picture_ids[x.strip()] for x in labels if x.strip() in self._picture_ids)

    def add(self, op: _AddItemOp) -> None:
        """Queue an add, its label respelled to the one on file; refused when it is not a new fact for its bucket."""
        if not isinstance(op.data, _REPLY_SHAPES[op.bucket]):
            self._reject("add", op.bucket, "data not shaped for its bucket")
            return
        data = op.data.model_dump()
        key = _identity_key(data["description"])
        if key is None:
            self._reject("add", op.bucket, "missing description")
            return
        if key in self.held[op.bucket]:
            self._reject("add", op.bucket, "already on file")
            return
        self.held[op.bucket].add(key)
        self._respell_label(op.bucket, data)
        self.adds[op.bucket].append(_Queued(data, self.sources(op.sources), self.pictures(op.pictures)))

    def modify(self, op: _ModifyItemOp) -> None:
        """Queue a modify of the item its ref names; two on one item merge in order."""
        ref = self._ref(op.ref, "modify")
        if ref is None or not self._modify_allowed(op, ref):
            return
        prior = self.patches.get(ref)
        data = {**(prior.data if prior else {}), **op.data.model_dump()}
        self.patches[ref] = _Queued(
            data,
            _union(prior.sources if prior else (), self.sources(op.sources)),
            _union(prior.pictures if prior else (), self.pictures(op.pictures)),
        )
        if (key := _identity_key(data["description"])) is not None:
            self.held[ref[0]].add(key)

    def deprecate(self, op: _DeprecateItemOp) -> None:
        """Queue a deprecation of the item its ref names; it overrides a modify of that item in the same reply."""
        ref = self._ref(op.ref, "deprecate")
        if ref is None or self._stale("deprecate", ref, self.shown[ref[0]][ref[1]].item):
            return
        if self.patches.pop(ref, None) is not None:
            self._reject("modify", ref[0], "deprecated by the same reply")
        self.deprecations[ref] = (op.reason, self.sources(op.sources))

    def apply(self, state: ProfileState) -> None:
        """Replace ``state``'s buckets with the queued result: patched in place, deprecations out, adds appended."""
        for bucket in BUCKETS:
            entries: list[_Working] = []
            for index, entry in enumerate(self.shown[bucket]):
                ref = (bucket, index)
                if ref in self.deprecations:
                    reason, sources = self.deprecations[ref]
                    state.retired.append(_Retirement(ref, entry.stored or entry.item, "deprecated", reason, sources))
                elif ref in self.patches:
                    entries.append(self._modified(state, entry, ref, self.patches[ref]))
                else:
                    entries.append(entry)
            for queued in self.adds[bucket]:
                item = _ITEM_MODELS[bucket].model_validate({**queued.data, _OBSERVED_AT: self._observed_at})
                entries.append(_Working(item, "added", (), queued.sources, queued.pictures))
            state.buckets[bucket] = entries

    def _modified(self, state: ProfileState, entry: _Working, ref: ItemRef, queued: _Queued) -> _Working:
        """The entry a modify leaves: the stored item patched in place, so every key a host attached stays on it.

        A new value takes the segments' date and retires the stored item as ``modified``; fresh evidence for the
        same value keeps the item's date and retires nothing.
        """
        rewrites = _changes_description(entry.item, queued.data)
        patch = {**queued.data, _OBSERVED_AT: self._observed_at} if rewrites else queued.data
        modified = _Working(
            _patched(entry.item, patch),
            "modified",
            entry.from_items,
            _union(entry.sources, queued.sources),
            _union(entry.pictures, queued.pictures),
            stored=None if rewrites else entry.stored,
        )
        if rewrites:
            self.counts.rewrote += 1
            if entry.stored is not None:
                state.retired.append(_Retirement(ref, entry.stored, "modified", replaced_by=[modified]))
        return modified

    def _modify_allowed(self, op: _ModifyItemOp, ref: ItemRef) -> bool:
        bucket, index = ref
        item = self.shown[bucket][index].item
        new_key = _identity_key(op.data.description)
        reason = None
        if not isinstance(op.data, _REPLY_SHAPES[bucket]):
            reason = "data not shaped for its bucket"
        elif ref in self.deprecations:
            reason = "deprecated by the same reply"
        elif new_key is None:
            reason = "missing description"
        elif new_key != _identity_key(item.description) and new_key in self.held[bucket]:
            reason = "would duplicate another item"
        if reason is not None:
            self._reject("modify", bucket, reason)
            return False
        return not (_changes_description(item, op.data.model_dump()) and self._stale("modify", ref, item))

    def _respell_label(self, bucket: Bucket, data: dict[str, Any]) -> None:
        """Respell an add's label to the spelling on file, so one dimension does not split into variants."""
        label_field = _LABEL_FIELDS[bucket]
        label = data.get(label_field)
        if not isinstance(label, str) or not label.strip():
            return
        wanted = _normalize(label)
        on_file = next(
            (now for e in self.shown[bucket] if (now := _label(e.item)) is not None and _normalize(now) == wanted),
            None,
        )
        if on_file is not None and on_file != label:
            logger.debug(
                "profile add label canonicalised: bucket=%s from_len=%d to_len=%d", bucket, len(label), len(on_file)
            )
            self.counts.canonicalised += 1
            data[label_field] = on_file

    def _ref(self, text: str, action: str) -> ItemRef | None:
        """The place a ref names in the profile the model was shown; None, logged and counted, when it names none."""
        ref = _parse_ref(text)
        if ref is None or not 0 <= ref[1] < len(self.shown[ref[0]]):
            logger.warning("profile update op rejected: action=%s ref_len=%d reason=unknown ref", action, len(text))
            self.counts.rejected += 1
            return None
        return ref

    def _stale(self, action: str, ref: ItemRef, item: _Item) -> bool:
        """True, logged and counted, when ``item`` was established after the segments the reply read."""
        established = _stale_since(item, self._observed_at)
        if established is None:
            return False
        logger.warning(
            "profile update op rejected: action=%s type=%s reason=stale evidence item_observed_at_ms=%d "
            "batch_observed_at_ms=%d",
            action,
            ref[0],
            established,
            self._observed_at,
        )
        self.counts.rejected += 1
        return True

    def _reject(self, action: str, bucket: str, reason: str) -> None:
        logger.warning("profile update op rejected: action=%s type=%s reason=%s", action, bucket, reason)
        self.counts.rejected += 1


def apply_update(
    state: ProfileState,
    reply: _ProfileUpdateReply,
    *,
    observed_at: int,
    segment_ids: Mapping[str, str],
    picture_ids: Mapping[str, str],
) -> UpdateCounts:
    """Apply an update reply's operations to ``state`` in place; return what they did.

    Every ref resolves against the profile as the model was shown it, before any operation applies. ``observed_at``,
    the newest segment's time, dates added items and new values, and refuses as stale a deprecation or a new value
    of an item established after it (fresh evidence for it still lands). ``segment_ids`` / ``picture_ids`` map the
    labels the prompt showed to the host's ids; an operation naming no segment it was shown rests on all of them.
    """
    plan = _UpdatePlan(state, observed_at=observed_at, segment_ids=segment_ids, picture_ids=picture_ids)
    for op in reply.operations:
        plan.counts.actions[op.action] += 1
        if isinstance(op, _AddItemOp):
            plan.add(op)
        elif isinstance(op, _ModifyItemOp):
            plan.modify(op)
        elif isinstance(op, _DeprecateItemOp):
            plan.deprecate(op)
    plan.apply(state)
    return plan.counts


# --------------------------------------------------------------------------------------------------
# Consolidation: when, and what its reply does
# --------------------------------------------------------------------------------------------------


@dataclass(frozen=True)
class Scope:
    """The part of the profile one consolidation rewrites: the whole of it, one bucket, or one name of one bucket."""

    bucket: Bucket | None = None
    label: str | None = None

    @property
    def whole(self) -> bool:
        """True for the whole profile."""
        return self.bucket is None

    @property
    def bucket_wide(self) -> bool:
        """True for every item of one bucket (the traits)."""
        return self.bucket is not None and self.label is None

    def describe(self) -> str:
        """The scope as :attr:`~._result.ProfileUpdate.consolidated` lists it."""
        if self.bucket is None:
            return "profile"
        return self.bucket if self.label is None else f"{self.bucket}:{self.label}"


def _unmarked(item: _Item) -> bool:
    """True for an item added since the last consolidation of its part."""
    return (item.model_extra or {}).get(_CONSOLIDATED_AT) is None


def consolidation_scopes(state: ProfileState) -> list[Scope]:
    """The parts to consolidate now: the whole profile, else each name that needs it; possibly none.

    The whole profile when it holds more than ``_PROFILE_MAX_ITEMS`` items, ``_PROFILE_GROWTH`` of them added since
    its last whole consolidation. Otherwise every trait when there are more than ``_TRAITS_MAX``, ``_TRAITS_GROWTH``
    of them added since the traits were last consolidated (then no trait name on its own), and each name holding
    more than ``_PROFILE_MAX_PER_CATEGORY`` items, ``_CATEGORY_GROWTH`` of them added since that name was last
    consolidated, or holding a newly added item past the width backstop. A part over its cap that has not grown that
    much is logged and left alone.
    """
    entries = [entry for bucket in BUCKETS for entry in state.buckets[bucket]]
    if len(entries) > _PROFILE_MAX_ITEMS:
        grown = sum(1 for entry in entries if _unmarked(entry.item))
        if grown >= _PROFILE_GROWTH:
            return [Scope()]
        logger.info(
            "profile over its total cap but not grown since its last consolidation, skipped: count=%d new=%d",
            len(entries),
            grown,
        )
    scopes = _name_scopes("explicit_info", state.buckets["explicit_info"])
    traits = state.buckets["implicit_traits"]
    if len(traits) > _TRAITS_MAX:
        grown = sum(1 for entry in traits if _unmarked(entry.item))
        if grown >= _TRAITS_GROWTH:
            return [*scopes, Scope("implicit_traits")]
        logger.info(
            "profile traits over their cap but not grown since their last consolidation, skipped: count=%d new=%d",
            len(traits),
            grown,
        )
    return [*scopes, *_name_scopes("implicit_traits", traits)]


def _name_scopes(bucket: Bucket, entries: Sequence[_Working]) -> list[Scope]:
    """The names of one bucket over their cap and grown enough, or holding a new over-wide item."""
    groups: dict[str, list[_Item]] = {}
    spelling: dict[str, str] = {}
    for entry in entries:
        label = _item_label(entry.item)
        if label is not None:
            spelling.setdefault(_normalize(label), label)
            groups.setdefault(_normalize(label), []).append(entry.item)
    scopes: list[Scope] = []
    for key, items in groups.items():
        grown = sum(1 for item in items if _unmarked(item))
        wide = any(_unmarked(item) and ascii_width(item.description) > _ITEM_WIDTH_BACKSTOP for item in items)
        over = len(items) > _PROFILE_MAX_PER_CATEGORY
        if wide or (over and grown >= _CATEGORY_GROWTH):
            scopes.append(Scope(bucket, spelling[key]))
        elif over:
            logger.info(
                "profile group over cap but not grown since its last consolidation, skipped: bucket=%s label_len=%d "
                "count=%d new=%d",
                bucket,
                len(spelling[key]),
                len(items),
                grown,
            )
    return scopes


def scope_entries(state: ProfileState, scope: Scope) -> list[tuple[ItemRef, _Working]]:
    """The entries ``scope`` shows the model, each with its place in the current profile."""
    if scope.bucket is None:
        return [((bucket, i), entry) for bucket in BUCKETS for i, entry in enumerate(state.buckets[bucket])]
    if scope.label is None:
        return [((scope.bucket, i), entry) for i, entry in enumerate(state.buckets[scope.bucket])]
    wanted = _normalize(scope.label or "")
    return [
        ((scope.bucket, i), entry)
        for i, entry in enumerate(state.buckets[scope.bucket])
        if (label := _item_label(entry.item)) is not None and _normalize(label) == wanted
    ]


def other_names(state: ProfileState, scope: Scope) -> list[str]:
    """The names in use outside ``scope`` in its bucket, first-seen order; none for the whole profile or bucket."""
    if scope.bucket is None or scope.label is None:
        return []
    wanted = _normalize(scope.label or "")
    names: dict[str, str] = {}
    for entry in state.buckets[scope.bucket]:
        label = _item_label(entry.item)
        if label is not None and _normalize(label) != wanted:
            names.setdefault(_normalize(label), label)
    return list(names.values())


@dataclass
class ConsolidationCounts:
    """What one consolidation reply did, for the ``profile consolidated`` line."""

    shown: int = 0
    written: int = 0
    merged: int = 0
    refiled: int = 0
    unchanged: int = 0
    dropped: int = 0
    refused: int = 0


class _ConsolidationPlan:
    """A consolidation reply resolved against the entries it showed, before any of it applies."""

    def __init__(self, state: ProfileState, scope: Scope, *, consolidated_at: int) -> None:
        shown = scope_entries(state, scope)
        self.by_ref = {_item_ref(ref): entry for ref, entry in shown}
        self.bucket_of = {id(entry): ref[0] for ref, entry in shown}
        self.replaced: dict[int, list[_Working]] = {}
        self.refiled: dict[int, dict[str, Any]] = {}
        self.drops: dict[int, str] = {}
        self.counts = ConsolidationCounts(shown=len(shown))
        self._consolidated_at = consolidated_at

    def write(self, written: _ConsolidatedItem) -> None:
        """Queue one written item: a re-filing of the one item it names, or a new item replacing those it names."""
        bucket: Bucket = "explicit_info" if isinstance(written, _ConsolidatedExplicit) else "implicit_traits"
        named = [self.by_ref.get(_canonical_ref(text)) for text in written.from_refs]
        sources = list(dict.fromkeys(e for e in named if e is not None and self.bucket_of[id(e)] == bucket))
        data = written.model_dump(exclude={"from_refs"})
        if not sources or _identity_key(data["description"]) is None:
            self.counts.refused += 1
            return
        if len(sources) == 1 and not _changes_description(sources[0].item, data):
            self.refiled[id(sources[0])] = data
            label = _LABEL_FIELDS[bucket]
            if data.get(label) == getattr(sources[0].item, label, None):
                self.counts.unchanged += 1  # restated as it was: output spent on nothing
            else:
                self.counts.refiled += 1
            return
        self.counts.written += 1
        self.counts.merged += len(sources) > 1
        new = _consolidated(bucket, data, sources, self._consolidated_at)
        for entry in sources:
            self.replaced.setdefault(id(entry), []).append(new)

    def drop(self, ref: str, reason: str) -> None:
        """Queue one drop; refused when the ref names no shown item or one a written item already took."""
        entry = self.by_ref.get(_canonical_ref(ref))
        if entry is None or id(entry) in self.replaced:
            self.counts.refused += 1
            return
        self.drops[id(entry)] = reason
        self.counts.dropped = len(self.drops)

    def apply(self, state: ProfileState) -> None:
        """Rebuild ``state``'s buckets: each written item at its first source's place, drops out, the rest marked."""
        for bucket in BUCKETS:
            entries: list[_Working] = []
            for entry in state.buckets[bucket]:
                entries.extend(self._after(state, entry, entries))
            state.buckets[bucket] = entries

    def _after(self, state: ProfileState, entry: _Working, placed: Sequence[_Working]) -> list[_Working]:
        """What takes ``entry``'s place: its successors not yet placed, nothing, or itself."""
        if id(entry) in self.replaced:
            successors = self.replaced[id(entry)]
            state.retire(entry, "consolidated", by=successors)
            entry.successors = successors
            return [new for new in successors if not any(new is done for done in placed)]
        if id(entry) in self.drops:
            state.retire(entry, "consolidated", reason=self.drops[id(entry)])
            entry.successors = []
            return []
        if id(entry) in self.bucket_of:
            patch = {**self.refiled.get(id(entry), {}), _CONSOLIDATED_AT: self._consolidated_at}
            entry.item = _patched(entry.item, patch)
        return [entry]


def apply_consolidation(
    state: ProfileState, scope: Scope, reply: _ConsolidateReply, *, consolidated_at: int
) -> ConsolidationCounts:
    """Apply a consolidation reply to ``state`` in place; return what it did.

    A written item replaces the items its ``from`` names, at the place of the first of them, and takes the newest of
    their dates and the union of their lineage; one that names a single item and states its fact unchanged only
    re-files that item, in place, so the item keeps every key a host attached. A dropped item leaves with its reason.
    Every item of the part that stays is marked ``consolidated_at``, so the part counts its growth from here. A
    written item naming no item the call showed, or only items of another bucket, is refused, and so is a drop of an
    item a written item took.
    """
    plan = _ConsolidationPlan(state, scope, consolidated_at=consolidated_at)
    for written in reply.changes:
        plan.write(written)
    for dropped in reply.dropped:
        plan.drop(dropped.ref, dropped.reason)
    plan.apply(state)
    return plan.counts


def _consolidated(
    bucket: Bucket, data: Mapping[str, Any], sources: Sequence[_Working], consolidated_at: int
) -> _Working:
    """The entry a written item becomes: the newest date of what it came from, and the union of their lineage."""
    dates = [entry.item.observed_at for entry in sources if entry.item.observed_at is not None]
    item = _ITEM_MODELS[bucket].model_validate(
        {**data, _OBSERVED_AT: max(dates, default=consolidated_at), _CONSOLIDATED_AT: consolidated_at}
    )
    return _Working(
        item,
        "consolidated",
        _union(*(entry.from_items for entry in sources)),
        _union(*(entry.sources for entry in sources)),
        _union(*(entry.pictures for entry in sources)),
    )


def _canonical_ref(text: str) -> str:
    """A reply's ref as the prompt wrote it (``e3``), or ``""`` when it names no place."""
    ref = _parse_ref(text)
    return _item_ref(ref) if ref is not None else ""
