"""The extraction stages, each its message templates, language rules and reply model.

The MemCell path has two prompts, UPDATE (of an empty profile too, which is what INIT was) and CONSOLIDATE; the
Episode path has INIT, UPDATE, COMPACT and REGROUP. Every stage is a system message of rules and a user message of
data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from everalgo.llm import LLMMessage, StrictOutputModel
from everalgo.user_memory._language import (
    COMPACTED_PROFILE_LANGUAGE_RULE,
    EPISODE_PROFILE_INIT_LANGUAGE_RULE,
    EXISTING_PROFILE_LANGUAGE_RULE,
    MEMCELL_CONSOLIDATED_PROFILE_LANGUAGE_RULE,
    MEMCELL_EXISTING_PROFILE_LANGUAGE_RULE,
    PROFILE_INIT_LANGUAGE_RULE,
    REGROUPED_PROFILE_LANGUAGE_RULE,
    OutputLanguage,
    build_language_rule,
)
from everalgo.user_memory.profile._replies import (
    _CompactOutput,
    _ConsolidateReply,
    _ProfileItems,
    _ProfileUpdateReply,
    _RegroupOutput,
    _UpdateOutput,
)
from everalgo.user_memory.prompts.en.profile import (
    PROFILE_CONSOLIDATE_SYSTEM_PROMPT,
    PROFILE_CONSOLIDATE_USER_PROMPT,
    PROFILE_UPDATE_SYSTEM_PROMPT,
    PROFILE_UPDATE_USER_PROMPT,
)
from everalgo.user_memory.prompts.en.profile_from_episode_texts import (
    PROFILE_COMPACT_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
    PROFILE_COMPACT_FROM_EPISODE_TEXTS_USER_PROMPT,
    PROFILE_INITIAL_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
    PROFILE_INITIAL_FROM_EPISODE_TEXTS_USER_PROMPT,
    PROFILE_REGROUP_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
    PROFILE_REGROUP_FROM_EPISODE_TEXTS_USER_PROMPT,
    PROFILE_UPDATE_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
    PROFILE_UPDATE_FROM_EPISODE_TEXTS_USER_PROMPT,
    additional_requirements_block,
)
from everalgo.utils import render_prompt


@dataclass(frozen=True, kw_only=True)
class _StagePrompts[ReplyT: StrictOutputModel]:
    """Message templates of one extraction stage, its language rules, and the model its reply is validated against.

    Args:
        user: Template of the user message, the per-request data.
        reply: Output model of the stage's reply — the shape the stage's reply skeleton shows the model.
        language_fallback: Output-language rule used when the caller names no language, naming the input the
            stage takes its language from.
        system: Template of the system message holding the rules; free of per-request data.
    """

    user: str
    reply: type[ReplyT]
    language_fallback: str
    system: str

    def language_rule(self, output_language: OutputLanguage | str | None) -> str:
        """The output-language rule for ``output_language``: the caller-chosen rule, else this stage's fallback.

        Raises:
            InvalidInputError: If ``output_language`` names no known language.
        """
        return build_language_rule(output_language, fallback=self.language_fallback)

    def render(self, *, custom_instructions: str | None, **fields: Any) -> list[LLMMessage]:
        """Render the system message (where the stage has one) and the user message from the same ``fields``.

        ``custom_instructions`` land after the rules and before the data, as text rather than template; None or a
        blank string adds nothing.
        """
        requirements = custom_instructions if custom_instructions is not None and custom_instructions.strip() else None
        system = render_prompt(self.system, None, **fields)
        if requirements is not None:
            system = f"{system}\n\n{additional_requirements_block(requirements)}"
        user = render_prompt(self.user, None, **fields)
        return [LLMMessage(role="system", content=system), LLMMessage(role="user", content=user)]


_MEMCELL_FIRST_UPDATE = _StagePrompts(
    user=PROFILE_UPDATE_USER_PROMPT,
    reply=_ProfileUpdateReply,
    language_fallback=PROFILE_INIT_LANGUAGE_RULE,
    system=PROFILE_UPDATE_SYSTEM_PROMPT,
)
"""The update of an empty profile: the call that fixes a profile's language when the caller names none."""
_MEMCELL_UPDATE = _StagePrompts(
    user=PROFILE_UPDATE_USER_PROMPT,
    reply=_ProfileUpdateReply,
    language_fallback=MEMCELL_EXISTING_PROFILE_LANGUAGE_RULE,
    system=PROFILE_UPDATE_SYSTEM_PROMPT,
)
_MEMCELL_CONSOLIDATE = _StagePrompts(
    user=PROFILE_CONSOLIDATE_USER_PROMPT,
    reply=_ConsolidateReply,
    language_fallback=MEMCELL_CONSOLIDATED_PROFILE_LANGUAGE_RULE,
    system=PROFILE_CONSOLIDATE_SYSTEM_PROMPT,
)
_EPISODE_INIT = _StagePrompts(
    user=PROFILE_INITIAL_FROM_EPISODE_TEXTS_USER_PROMPT,
    reply=_ProfileItems,
    language_fallback=EPISODE_PROFILE_INIT_LANGUAGE_RULE,
    system=PROFILE_INITIAL_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
)
_EPISODE_UPDATE = _StagePrompts(
    user=PROFILE_UPDATE_FROM_EPISODE_TEXTS_USER_PROMPT,
    reply=_UpdateOutput,
    language_fallback=EXISTING_PROFILE_LANGUAGE_RULE,
    system=PROFILE_UPDATE_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
)
_EPISODE_COMPACT = _StagePrompts(
    user=PROFILE_COMPACT_FROM_EPISODE_TEXTS_USER_PROMPT,
    reply=_CompactOutput,
    language_fallback=COMPACTED_PROFILE_LANGUAGE_RULE,
    system=PROFILE_COMPACT_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
)
_EPISODE_REGROUP = _StagePrompts(
    user=PROFILE_REGROUP_FROM_EPISODE_TEXTS_USER_PROMPT,
    reply=_RegroupOutput,
    language_fallback=REGROUPED_PROFILE_LANGUAGE_RULE,
    system=PROFILE_REGROUP_FROM_EPISODE_TEXTS_SYSTEM_PROMPT,
)
